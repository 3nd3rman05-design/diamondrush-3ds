# Diamond Rush 3DS

Port per 3DS del Diamond Rush J2ME, basato sul core libretro **FroggyKVM** (PSPKVM/phoneME).
In partita: schermo superiore = area di gioco a 1:1, schermo inferiore = vite, chiavi, energia.
Menu, mappa, sigillo, pagine di testo: tutta la schermata del gioco sopra (ridotta al 75%).
Sotto ci sono sempre i tasti touch e le impostazioni.

## Novità della versione 2
- **Menu tutto sopra**: titolo, menu, caricamento, mappa, sigillo, cheat, game over e riepilogo del livello
  stanno interi sullo schermo superiore. In partita (anche con pausa e dialoghi) resta la vista divisa.
  Il frontend riconosce la schermata dai pixel fissi delle barre di stato.
- **Musica corretta e molto più leggera** (core, `port/patch_core.py` punti 8-14). Il core originale:
  saltava l'evento MIDI dopo ogni nota e lasciava accese le note dei brani appena caricati
  (fino a 250 voci contemporanee, mentre i brani suonano al massimo 24 note insieme),
  suonava la musica 1,6-2 volte troppo veloce e la risintetizzava a ogni ripetizione.
  Su PC il lavoro della CPU è sceso di circa 2,2 volte sul titolo e 1,6 in partita.
- **Audio: muto** ora ferma anche la sintesi della musica: il gioco va più veloce.
- **SELECT+START** insieme non chiudono più il gioco (era la combinazione d'uscita dell'SF2000).

## Novità della versione 2.1 (Old 3DS)
Misurato su PC con callgrind, stessa sequenza di gioco: da 3,34 a 2,49 milioni di istruzioni per
fotogramma in partita (-25%).
- Il mixer audio guarda solo i player che suonano, invece di 64 posti per ogni campione (-82% nel mixer).
- Il ciclo dell'interprete Java tiene il suo contatore in un registro (-13% nell'interprete).
- La copia dell'immagine sugli schermi lavora a blocchi 2x2 da 32 bit (-25% nel frontend).
Sul 3DS il guadagno reale si vede solo misurando: la riga in basso mostra gli fps.

## Novità della versione 2.2 (audio)
- **Suoni ripetuti all'infinito** (per esempio aprendo una cassa): il core faceva ripartire da solo
  ogni brano MIDI e non diceva mai al gioco che il suono era finito. Il gioco, convinto che il suono
  stesse ancora suonando, scartava anche gli effetti meno importanti (per esempio quello dei dialoghi).
  Ora ogni suono suona una volta e il gioco riceve la fine del brano, come su un telefono vero
  (`port/patch_core.py` punti 17-19).
- **La musica del titolo suona una volta sola**, poi c'è silenzio: il gioco non la ripete mai
  (non usa `setLoopCount`), quindi è così anche sul telefono. Prima andava in loop per lo stesso difetto.
- Gli effetti finiscono con la loro coda naturale invece di essere tagliati all'ultima nota (niente click).

## Novità della versione 2.3 (velocità)
Misurato con qemu-arm sul codice ARM compilato con gli stessi flag del 3DS, stessa sequenza di gioco:
da 2,32 a 1,79 milioni di istruzioni per fotogramma in partita (-23%).
- L'interprete Java tiene program counter, cima dello stack e variabili locali fissi in tre registri
  della CPU invece che in memoria (`port/patch_core.py` punto 20): -30% di istruzioni nell'interprete.
  Con la stessa sequenza di tasti il gioco scrive lo stesso identico salvataggio su PC e su ARM.
- La musica si sintetizza in float invece che in double (punto 22): l'unità VFP del 3DS li calcola
  più in fretta. Questo guadagno su PC non si può misurare.
- Quando parte un suono mai sentito prima, la sintesi è distribuita su più fotogrammi invece di
  bloccare il gioco per qualche fotogramma (punto 21).
- Mixer audio a blocchi (-80% nel mixer); copia dell'immagine sugli schermi con le istruzioni
  PKHBT/PKHTB dell'ARMv6 (-17% nella copia).
- Corretto: con l'audio muto, l'ultimo suono richiesto restava "in corso" e partiva in ritardo
  quando si riattivava l'audio.

Il gioco **non** è incluso: il `.jar` resta sulla tua SD. In questo repository ci sono solo codice GPL e grafica originale.

## Contenuto
- `port/patch_core.py` – modifiche a FroggyKVM per il 3DS (ARM11, percorsi, immagine nativa, musica MIDI)
- `port/ci.sh` – build completa (core, frontend, CIA, QR)
- `source/main.c` – frontend 3DS
- `Makefile` – build devkitARM del frontend
- `meta/` – RSF della CIA, icona, banner e suono originali, già convertiti in `icon.icn` e `banner.bnr`
- `.github/workflows/build.yml` – workflow GitHub Actions

## Installazione (da telefono)
1. Crea un repository **pubblico** su GitHub, per esempio `diamondrush-3ds`.
2. *Add file → Upload files*: carica `port3ds.zip` e fai *Commit*.
3. *Add file → Create new file*: come nome scrivi `.github/workflows/build.yml`, incolla il contenuto del workflow e fai *Commit*. La build parte da sola.
4. Scheda *Actions*: se il run diventa rosso, apri il passo fallito e manda il log.
5. Quando è verde: *Releases* → l'ultima build → apri `DiamondRush3DS-QR.png`.
6. Sul 3DS: FBI → *Remote Install* → *Scan QR Code* → inquadra il QR.
7. Con ftpd copia il `.jar` 1.1.7 (quello senza suffisso) in `sdmc:/3ds/diamondrush/` e rinominalo `game.jar`.
8. Avvia **Diamond Rush** dalla HOME.

Per aggiornare: carica il nuovo `port3ds.zip` al posto del vecchio. Ogni commit avvia una nuova build.

## File sulla SD (`sdmc:/3ds/diamondrush/`)
| File | Cosa fa |
|---|---|
| `game.jar` | il gioco (lo copi tu) |
| `game.cfg` | creato al primo avvio: risoluzione del .jar, heap, tasti |
| `frontend.ini` | creato al primo avvio: schermo (auto/intero/diviso), righe di taglio, log, audio, vsync |
| `log.txt` | diagnostica dell'ultimo avvio (massimo 512 KB) |
| `saves/` | salvataggi automatici del gioco |
| `music.sf2` | facoltativo: un tuo SoundFont al posto di TimGM6mb |

L'audio richiede `sdmc:/3ds/dspfirm.cdc` (dump di DSP1). Se manca, il gioco gira senza suono
(e senza sintetizzare la musica, quindi più veloce).

## Comandi
| 3DS | Nel gioco |
|---|---|
| D-pad / Circle Pad | movimento (tasti 2/4/6/8) |
| A, X | OK / azione (tasto 5) |
| START, L | menu di pausa; "Salta" nei dialoghi (tasto funzione sinistro) |
| B, Y, R | indietro nei menu (tasto funzione destro) |
| SELECT | torna all'ultimo checkpoint (tasto *): costa una vita se non ci sei sopra |

I tasti 0 e # servono solo per i cheat: li trovi in *Cheat / Tastiera*.
Sul touch ci sono le stesse funzioni, più *Schermo*, *Audio* (acceso/muto), *Cheat / Tastiera* ed *Esci*.
*Checkpoint* ed *Esci* vanno toccati due volte. Per uscire si usa *Esci* (o la HOME).

## Schermo
Il tasto touch *Schermo* cambia modo a ogni tocco e lo salva in `frontend.ini` (`schermo = ...`):
| Modo | Cosa fa |
|---|---|
| `auto` (predefinito) | in partita campo sopra e barre sotto; menu, mappa e pagine di testo interi sopra |
| `intero` | sempre tutta la schermata sopra, ridotta al 75% |
| `diviso` | sempre campo sopra e barre sotto (come la versione 1) |

`auto` riconosce la partita solo con la 1.1.7 a 240x320. Con un altro .jar alto 320 righe resta "intero":
usa `diviso` se preferisci. La 1.2.0 (176x204) entra intera a 1:1 e non viene ridotta.

## Cheat
1. Tocca **Cheat / Tastiera**: compare il tastierino del telefono (0-9, *, #) con *Cheat #4772*, *Lista cheat*, *Menu/Salta*, *Indietro* e *Chiudi*. I tasti fisici continuano a funzionare.
2. Durante un livello, o sulla mappa, tocca **Cheat #4772**: si apre la pagina dei cheat del gioco.
3. **Lista cheat** mostra l'elenco qui sotto sullo schermo inferiore; un tocco la chiude.

Sulla pagina dei cheat:
| Tasto | Effetto |
|---|---|
| 6 | +50 diamanti a ogni pressione (provato) |
| 7 | +5 diamanti rossi |
| 8 | armi disponibili: funziona solo se la pagina è aperta dalla mappa |
| 9 | sblocca tutti i livelli (provato) |
| 0 | sblocca i livelli segreti |
| # | attiva il salta-livello (provato) |
| Menu/Salta | applica e salva (provato) |
| Indietro | esce senza applicare |

Con il salta-livello attivo, in gioco: **9** = livello superato, **7** = torna alla mappa (provati entrambi).
Sempre: **\*** riporta all'ultimo cerchio magico e costa una vita (provato).

## Salvataggi
Il gioco salva da solo: non c'è un comando di salvataggio. Scrive le impostazioni e i progressi
(livelli completati, acquisti, mondi sbloccati) in `sdmc:/3ds/diamondrush/saves/`.
Chiudendo dalla HOME perdi solo quello che hai fatto dopo l'ultimo salvataggio automatico.

## Altre versioni del .jar
- **1.1.7 Nokia (240x320)**: impostazioni predefinite.
- **1.2.0 "(a)" (176x204)**: in `game.cfg` metti `resolution = 176x204`. Il frontend la mostra intera a 1:1.

## Old 3DS
Il core interpreta Java senza compilatore JIT: sull'Old 3DS il gioco resta più lento che sul New.
Se è lento: tocca *Audio* (muto: niente sintesi della musica).
Il gioco non ha un'opzione per togliere il suono: si fa dal tasto *Audio* del frontend.
La riga di stato in basso mostra modello e fps, per confrontare Old e New (il gioco va al massimo a circa 20 fps).

## Licenze
- FroggyKVM / PSPKVM / phoneME: GPL-2.0. Le modifiche di `port/` e `source/` sono GPL-2.0.
- `classes.zip`: dal rilascio FroggyKVM v1.1.1.
- TimGM6mb.sf2: GPL-2.0 (Tim Brechbill), dal pacchetto Debian `timgm6mb-soundfont`.
- Icona, banner e suono: originali di questo progetto.
- Diamond Rush è un marchio Gameloft. Nessun file del gioco è incluso.
