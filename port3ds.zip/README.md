# Diamond Rush 3DS

Port per 3DS del Diamond Rush J2ME, basato sul core libretro **FroggyKVM** (PSPKVM/phoneME).
Schermo superiore: area di gioco a 1:1. Schermo inferiore: vite, chiavi, energia, tasti touch e impostazioni.

Il gioco **non** è incluso: il `.jar` resta sulla tua SD. In questo repository ci sono solo codice GPL e grafica originale.

## Contenuto
- `port/patch_core.py` – modifiche a FroggyKVM per il 3DS (ARM11, percorsi, immagine nativa)
- `port/ci.sh` – build completa (core, frontend, CIA, QR)
- `source/main.c` – frontend 3DS
- `Makefile` – build devkitARM del frontend
- `meta/` – RSF della CIA, icona, banner e suono originali
- `.github/workflows/build.yml` – workflow GitHub Actions

## Installazione (da telefono)
1. Crea un repository **pubblico** su GitHub, per esempio `diamondrush-3ds`.
2. *Add file → Upload files*: carica `port3ds.zip` e fai *Commit*.
3. *Add file → Create new file*: come nome scrivi `.github/workflows/build.yml`, incolla il contenuto del workflow e fai *Commit*. La build parte da sola.
4. Scheda *Actions*: se il run diventa rosso, apri il passo fallito e manda il log.
5. Quando è verde: *Releases* → l'ultima build → apri `DiamondRush3DS-QR.png`.
6. Sul 3DS: FBI → *Remote Install* → *Scan QR Code* → inquadra il QR.
7. Con ftpd copia il `.jar` 1.1.7 (quello senza suffisso) in `sdmc:/3ds/diamondrush/` e rinominalo `game.jar`.
8. Avvia **Diamond Rush** dalla HOME.

Per aggiornare: carica il nuovo `port3ds.zip` al posto del vecchio. Ogni commit avvia una nuova build.

## File sulla SD (`sdmc:/3ds/diamondrush/`)
| File | Cosa fa |
|---|---|
| `game.jar` | il gioco (lo copi tu) |
| `game.cfg` | creato al primo avvio: risoluzione del .jar, heap, tasti |
| `frontend.ini` | creato al primo avvio: schermo diviso/centro, righe di taglio, log, vsync |
| `log.txt` | diagnostica dell'ultimo avvio (massimo 512 KB) |
| `saves/` | salvataggi automatici del gioco |
| `music.sf2` | facoltativo: un tuo SoundFont al posto di TimGM6mb |

L'audio richiede `sdmc:/3ds/dspfirm.cdc` (dump di DSP1). Se manca, il gioco gira senza suono.

## Comandi
| 3DS | Nel gioco |
|---|---|
| D-pad / Circle Pad | movimento (tasti 2/4/6/8) |
| A, X | OK / azione (tasto 5) |
| START, L | menu di pausa; "Salta" nei dialoghi (tasto funzione sinistro) |
| B, Y, R | indietro nei menu (tasto funzione destro) |
| SELECT | torna all'ultimo checkpoint (tasto *): costa una vita se non ci sei sopra |

I tasti 0 e # servono solo per i cheat: li trovi in *Cheat / Tastiera*.
Sul touch ci sono le stesse funzioni, più *Schermo* (diviso/centrato), *Audio* (acceso/muto), *Cheat / Tastiera* ed *Esci*.
*Checkpoint* ed *Esci* vanno toccati due volte.

## Cheat
1. Tocca **Cheat / Tastiera**: compare il tastierino del telefono (0-9, *, #) con *Cheat #4772*, *Lista cheat*, *Menu/Salta*, *Indietro* e *Chiudi*. I tasti fisici continuano a funzionare.
2. Durante un livello, o sulla mappa, tocca **Cheat #4772**: si apre la pagina dei cheat del gioco.
3. **Lista cheat** mostra l'elenco qui sotto sullo schermo inferiore; un tocco la chiude.

Sulla pagina dei cheat:
| Tasto | Effetto |
|---|---|
| 6 | +50 diamanti a ogni pressione (provato) |
| 7 | +5 diamanti rossi |
| 8 | armi disponibili: funziona solo se la pagina è aperta dalla mappa |
| 9 | sblocca tutti i livelli (provato) |
| 0 | sblocca i livelli segreti |
| # | attiva il salta-livello (provato) |
| Menu/Salta | applica e salva (provato) |
| Indietro | esce senza applicare |

Con il salta-livello attivo, in gioco: **9** = livello superato, **7** = torna alla mappa (provati entrambi).
Sempre: **\*** riporta all'ultimo cerchio magico e costa una vita (provato).

## Salvataggi
Il gioco salva da solo: non c'è un comando di salvataggio. Scrive le impostazioni e i progressi
(livelli completati, acquisti, mondi sbloccati) in `sdmc:/3ds/diamondrush/saves/`.
Chiudendo dalla HOME perdi solo quello che hai fatto dopo l'ultimo salvataggio automatico.

## Altre versioni del .jar
- **1.1.7 Nokia (240x320)**: impostazioni predefinite.
- **1.2.0 "(a)" (176x204)**: in `game.cfg` metti `resolution = 176x204`. Il frontend passa da solo alla visualizzazione centrata.

## Old 3DS
Se è lento: all'avvio del gioco scegli *Sound off*, e in `frontend.ini` imposta `log = 0`.
La riga di stato in basso mostra modello e fps, per confrontare Old e New.

## Licenze
- FroggyKVM / PSPKVM / phoneME: GPL-2.0. Le modifiche di `port/` e `source/` sono GPL-2.0.
- `classes.zip`: dal rilascio FroggyKVM v1.1.1.
- TimGM6mb.sf2: GPL-2.0 (Tim Brechbill), dal pacchetto Debian `timgm6mb-soundfont`.
- Icona, banner e suono: originali di questo progetto.
- Diamond Rush è un marchio Gameloft. Nessun file del gioco è incluso.
