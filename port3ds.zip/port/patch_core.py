#!/usr/bin/env python3
# Diamond Rush 3DS - modifiche al sorgente di FroggyKVM per il 3DS (ARM11 + percorsi).
# Uso: python3 port/patch_core.py <cartella-froggykvm>
# Ogni modifica verifica di trovare esattamente il testo atteso: se il sorgente
# cambia, lo script si ferma invece di produrre una build sbagliata.
import pathlib
import sys

ROOT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "froggykvm")


def load(rel):
    data = (ROOT / rel).read_bytes().decode("latin-1")
    return data.splitlines(keepends=True)


def save(rel, lines):
    (ROOT / rel).write_bytes("".join(lines).encode("latin-1"))


def eol_of(line):
    return "\r\n" if line.endswith("\r\n") else "\n"


def find_unique(lines, rel, needle, exact=False):
    hits = [i for i, l in enumerate(lines)
            if (l.rstrip("\r\n") == needle if exact else needle in l)]
    if len(hits) != 1:
        sys.exit(f"[patch] {rel}: attesa 1 riga con {needle!r}, trovate {len(hits)}")
    return hits[0]


def replace_line(rel, needle, new_lines, exact=False, first=False):
    lines = load(rel)
    if first:
        hits = [i for i, l in enumerate(lines)
                if (l.rstrip("\r\n") == needle if exact else needle in l)]
        if not hits:
            sys.exit(f"[patch] {rel}: riga {needle!r} non trovata")
        i = hits[0]
    else:
        i = find_unique(lines, rel, needle, exact)
    eol = eol_of(lines[i])
    lines[i:i + 1] = [t + eol for t in new_lines]
    save(rel, lines)
    print(f"[patch] ok  {rel}")


def replace_block(rel, old, new):
    """Sostituisce un blocco di piu' righe che deve comparire esattamente una volta."""
    data = (ROOT / rel).read_bytes().decode("latin-1")
    eol = "\r\n" if "\r\n" in data else "\n"
    old = old.replace("\n", eol)
    new = new.replace("\n", eol)
    n = data.count(old)
    if n != 1:
        sys.exit(f"[patch] {rel}: blocco atteso 1 volta, trovato {n} volte:\n{old}")
    (ROOT / rel).write_bytes(data.replace(old, new).encode("latin-1"))
    print(f"[patch] ok  {rel}")


def replace_in_function(rel, signature, old, new, expected):
    """Sostituisce `old` con `new` solo dentro la funzione che inizia con `signature`
    (fino alla graffa che la chiude); le occorrenze devono essere esattamente `expected`."""
    data = (ROOT / rel).read_bytes().decode("latin-1")
    start = data.find(signature)
    if start < 0 or data.find(signature, start + 1) >= 0:
        sys.exit(f"[patch] {rel}: funzione {signature!r} non trovata o non unica")
    i = data.index("{", start)
    depth = 0
    for j in range(i, len(data)):
        if data[j] == "{":
            depth += 1
        elif data[j] == "}":
            depth -= 1
            if depth == 0:
                break
    body = data[start:j + 1]
    n = body.count(old)
    if n != expected:
        sys.exit(f"[patch] {rel}: in {signature!r} attese {expected} occorrenze di {old!r}, trovate {n}")
    data = data[:start] + body.replace(old, new) + data[j + 1:]
    (ROOT / rel).write_bytes(data.encode("latin-1"))
    print(f"[patch] ok  {rel}")


def insert_before(rel, needle, new_lines):
    lines = load(rel)
    i = find_unique(lines, rel, needle)
    eol = eol_of(lines[i])
    lines[i:i] = [t + eol for t in new_lines]
    save(rel, lines)
    print(f"[patch] ok  {rel}")


# 1) Piattaforma "ctr" (3DS, ARM11) nel Makefile del core
replace_line("Makefile", "ifeq ($(platform), sf2000)", [
    "ifeq ($(platform), ctr)",
    "    TOOLPFX := $(if $(DEVKITARM),$(DEVKITARM)/bin/,)arm-none-eabi-",
    "    TARGET := $(NAME)_libretro_ctr.a",
    "    CC = $(TOOLPFX)gcc",
    "    CXX = $(TOOLPFX)g++",
    "    AR = $(TOOLPFX)ar",
    "    CTR_FLAGS = -march=armv6k -mtune=mpcore -mfloat-abi=hard -mfpu=vfp -mtp=soft -mword-relocations"
    " -fno-short-enums -ffunction-sections -fdata-sections -D__3DS__ -DARM11 -DNO_THREADS"
    " -DPSP_COMPAT -DPRODUCT=1 -DFROGGY_NATIVE_FRAME -DFROGGY_SD_ROOT=\\\"sdmc:/3ds/diamondrush\\\"",
    # devkitARM usa GCC 16: il C di default e' C23 e alcuni vecchi avvisi sono diventati errori.
    # Il codice phoneME/PSPKVM e' del 2008: si compila con gli standard per cui e' stato scritto.
    "    override CFLAGS += $(CTR_FLAGS) -std=gnu11 -Wno-incompatible-pointer-types"
    " -Wno-implicit-function-declaration -Wno-int-conversion",
    "    override CXXFLAGS += $(CTR_FLAGS) -std=gnu++14 -fno-exceptions -fno-rtti -fpermissive",
    "    STATIC_LINKING = 1",
    "else ifeq ($(platform), sf2000)",
], exact=True, first=True)

# 2) ARM AAPCS: va_list e' una struct, non si puo' passare NULL
replace_line("pspkvm/cldc/src/vm/cpu/c/Interpreter_c.cpp",
             "invoke_native_entry(native_ptr, return_type, 0, NULL, r1, r2);", [
    "    { va_list no_args; memset(&no_args, 0, sizeof(no_args));"
    " invoke_native_entry(native_ptr, return_type, 0, no_args, r1, r2); }",
])

# 3) Breakpoint: il fallback usava un'istruzione x86 ("int $03")
replace_line("pspkvm/cldc/src/vm/share/utilities/GlobalDefinitions_gcc.hpp",
             '#  define panic() __asm__ ("break")', [
    '#  define panic() __asm__ ("break")',
    "#elif defined(__arm__)",
    "#  define BREAKPOINT __builtin_trap()",
    "#  define panic() __builtin_trap()",
], exact=True)

# 4) classes.zip dentro la RomFS della CIA (controllo di esistenza + classpath reale)
insert_before("pspkvm/platform_gb300/platform.c",
              'FROGGY_SD_ROOT "/cubegm/bios/classes.zip",',
              ['        "romfs:/classes.zip",'])
insert_before("pspkvm/cldc/src/vm/share/handles/Universe.cpp",
              'FROGGY_SD_ROOT "/cubegm/bios/classes.zip",',
              ['        "romfs:/classes.zip",'])

# 5) SoundFont: prima quello nella RomFS (TimGM6mb, GPL-2), poi uno personale sulla SD
insert_before("pspkvm/platform_gb300/audio.c",
              '"/mnt/sda1/bios/Roland_SC-55.sf2",',
              ['    "romfs:/TimGM6mb.sf2",',
               '    FROGGY_SD_ROOT "/music.sf2",'])

# 6) Salvataggi: FroggyKVM scrive in /mnt/sda1/system/saves (percorso dell'SF2000).
#    Sul 3DS vanno in sdmc:/3ds/diamondrush/saves.
replace_line("pspkvm/platform_gb300/rms_posix.c",
             'const char* custom = getenv("GB300_RMS_DIR");', [
    "#ifdef __3DS__",
    '        const char* custom = FROGGY_SD_ROOT "/saves";',
    "#else",
    '        const char* custom = getenv("GB300_RMS_DIR");',
    "#endif",
])

# 7) Frame nativo: consegna al frontend l'immagine J2ME senza ritagliarla a 320x240
insert_before("pspkvm/platform_gb300/video.c",
              "static int last_w = -1, last_h = -1;", [
    "#ifdef FROGGY_NATIVE_FRAME",
    "    {",
    "        retro_video_refresh_t native_vcb = gb300_get_video_cb();",
    "        if (native_vcb) native_vcb(src, src_w, src_h, src_pitch);",
    "        gb300_poll_events();",
    "        return;",
    "    }",
    "#endif",
])

# 8) MIDI con FluidLite: dopo ogni nota on/off l'indice dell'evento avanzava due volte,
#    saltando l'evento successivo (spesso il note-off). Insieme al punto 12: su PC
#    fino a 250 voci attive sul titolo, mentre il brano suona al massimo 24 note
#    insieme. Musica sbagliata e CPU sprecata: su PC la sintesi era circa il 60%
#    del lavoro sul titolo.
replace_block("pspkvm/platform_gb300/audio.c", """                fluid_synth_noteon(g_fl_synth, ch, note, vel);
                ms->curTick = e->tick;
                ms->ev_i++;
                continue;""", """                fluid_synth_noteon(g_fl_synth, ch, note, vel);
                continue;""")
replace_block("pspkvm/platform_gb300/audio.c", """                fluid_synth_noteoff(g_fl_synth, ch, note);
                ms->curTick = e->tick;
                ms->ev_i++;
                continue;""", """                fluid_synth_noteoff(g_fl_synth, ch, note);
                continue;""")

# 9) Brano MIDI finito: il core lo risintetizzava da capo (CPU) e, in piu', il
#    conteggio della memoria PCM cresceva a ogni giro senza mai scendere. Ora il PCM
#    gia' sintetizzato resta pronto per la prossima partenza; cosa succede a fine
#    brano lo decide wav_mix_frame() (punto 17).
replace_block("pspkvm/platform_gb300/audio.c", """        if (ms && ms->done && remaining > 0 && remaining < WAV_PCM_RATE / 4) {
            if (p->loopMidi) {
                ms->ev_i = 0;
                ms->curTick = 0;
                ms->done = 0;
                ms->looped = 0;
                p->pcmFrames = 0;
                p->pos = 0;
                remaining = 0;
            }
        }""", """        /* 3DS: brano finito: niente risintesi, il PCM resta pronto per la
         * prossima partenza (fine brano: wav_mix_frame()). */""")

# 10) FluidLite piu' leggero: niente riverbero/chorus, interpolazione lineare,
#     massimo 32 voci. Sull'altoparlante del 3DS la differenza non si sente.
#     Guadagno 0.6 invece di 0.2: corrette le note bloccate (punti 8 e 12) la musica
#     risultava 7 volte piu' bassa di prima; cosi' il picco resta sotto i 2/3 del massimo.
replace_block("pspkvm/platform_gb300/audio.c", """    g_fl_settings = new_fluid_settings();
    if (!g_fl_settings) return NULL;""", """    g_fl_settings = new_fluid_settings();
    if (!g_fl_settings) return NULL;
    fluid_settings_setstr(g_fl_settings, "synth.reverb.active", "no");
    fluid_settings_setstr(g_fl_settings, "synth.chorus.active", "no");
    fluid_settings_setint(g_fl_settings, "synth.polyphony", 32);
    fluid_settings_setnum(g_fl_settings, "synth.gain", 0.6);""")
replace_block("pspkvm/platform_gb300/audio.c", """            xlog("[AUDIO] FluidLite: soundfont %s wczytany\\n", g_fl_soundfonts[i]);
            return g_fl_synth;""", """            xlog("[AUDIO] FluidLite: soundfont %s wczytany\\n", g_fl_soundfonts[i]);
            fluid_synth_set_interp_method(g_fl_synth, -1, FLUID_INTERP_LINEAR);
            return g_fl_synth;""")

# 11) Audio spento dal frontend: niente sintesi MIDI (la parte che costa).
#     Il frontend scrive froggy_midi_off = 1 quando l'audio e' muto.
replace_block("pspkvm/platform_gb300/audio.c", """static void wav_topup_midi(void) {
    int i;""", """int froggy_midi_off = 0;

static void wav_topup_midi(void) {
    int i;
    if (froggy_midi_off) return;""")

# 12) Note rimaste accese nel sintetizzatore condiviso. Il gioco crea all'avvio una
#     ventina di player MIDI (musiche ed effetti) e per ognuno il core sintetizzava
#     subito 512 campioni: le prime note partivano, i loro note-off no. Ora:
#     - il prefisso iniziale e' silenzio (la sintesi parte quando il brano suona);
#     - ogni brano ricorda le note che ha acceso e le spegne quando viene fermato
#       o chiuso.
replace_block("pspkvm/platform_gb300/audio.c", """    int done;                /* all events consumed */
    int looped;              /* one loop of the track has been rendered */
};
static void midi_stream_free(midi_stream_t *ms) {
    if (!ms) return;""", """    int done;                /* all events consumed */
    int looped;              /* one loop of the track has been rendered */
    unsigned char fl_on[16][16]; /* 3DS: note FluidLite accese da questo brano */
};
/* 3DS: spegne nel sintetizzatore condiviso le note ancora accese da questo brano */
static void midi_fl_release(midi_stream_t *ms) {
    int ch, n;
    if (!ms || !g_fl_synth) return;
    for (ch = 0; ch < 16; ch++)
        for (n = 0; n < 128; n++)
            if (ms->fl_on[ch][n >> 3] & (1u << (n & 7)))
                fluid_synth_noteoff(g_fl_synth, ch, n);
    memset(ms->fl_on, 0, sizeof(ms->fl_on));
}
static void midi_stream_free(midi_stream_t *ms) {
    if (!ms) return;
    midi_fl_release(ms);""")
replace_block("pspkvm/platform_gb300/audio.c", """                fluid_synth_noteon(g_fl_synth, ch, note, vel);
                continue;""", """                fluid_synth_noteon(g_fl_synth, ch, note, vel);
                ms->fl_on[ch][note >> 3] |= (unsigned char)(1u << (note & 7));
                continue;""")
replace_block("pspkvm/platform_gb300/audio.c", """                fluid_synth_noteoff(g_fl_synth, ch, note);
                continue;""", """                fluid_synth_noteoff(g_fl_synth, ch, note);
                ms->fl_on[ch][note >> 3] &= (unsigned char)~(1u << (note & 7));
                continue;""")
replace_block("pspkvm/platform_gb300/audio.c", """        if (prefix > 0) {
            midi_stream_render(p, prefix);""", """        if (prefix > 0) {
            int16_t *np = NULL;
            if (g_fl_synth) {
                /* 3DS: 64 campioni di silenzio (3 ms) senza toccare il synth condiviso */
                if (prefix > 64) prefix = 64;
                np = (int16_t *)realloc(p->pcm, (size_t)prefix * 2);
            }
            if (np) {
                memset(np, 0, (size_t)prefix * 2);
                p->pcm = np;
                g_wav_pcm_total += (prefix - p->pcmFrames) * 2;
                p->pcmFrames = prefix;
            } else {
                midi_stream_render(p, prefix);
            }""")
replace_block("pspkvm/platform_gb300/audio.c", """    if (p) {
        p->playing = 0;
        p->paused = 0;
        p->pos = 0;
    }""", """    if (p) {
        p->playing = 0;
        p->paused = 0;
        p->pos = 0;
        if (p->midi) midi_fl_release((midi_stream_t *)p->midi);
    }""")

# 13) SELECT+START insieme chiudeva il gioco all'istante (era il menu dell'SF2000).
#     Sul 3DS SELECT e START sono tasti del gioco: si esce solo da "Esci".
replace_line("pspkvm/platform_gb300/platform.c",
             "if ((buttons & (PSP_CTRL_SELECT | PSP_CTRL_START)) == (PSP_CTRL_SELECT | PSP_CTRL_START)) {", [
    "        if (0) { /* 3DS: combinazione d'uscita disattivata */",
])

# 14) Tempo della musica. Quando un evento cadeva oltre la fine del blocco da
#     sintetizzare, veniva eseguito subito e il tempo mancante si perdeva: la
#     musica andava 1,6-2 volte piu' veloce (titolo: 23,7 s suonati in ~11,5 s).
#     Ora l'evento resta in attesa e si conta quanto e' gia' stato sintetizzato.
#     In piu': mono = media di sinistra e destra (prima restava solo la destra) e
#     il PCM del brano finito si ferma all'ultimo campione sintetizzato (prima in coda
#     restava il silenzio non usato dell'ultimo blocco).
replace_block("pspkvm/platform_gb300/audio.c", """    unsigned char fl_on[16][16]; /* 3DS: note FluidLite accese da questo brano */
};""", """    unsigned char fl_on[16][16]; /* 3DS: note FluidLite accese da questo brano */
    int64_t since;               /* 3DS: campioni gia' sintetizzati dopo curTick */
};""")
replace_block("pspkvm/platform_gb300/audio.c", """        int64_t target = outPos + (int64_t)(e->tick - ms->curTick) * ms->tempo * WAV_PCM_RATE /
                                   (1000000LL * ms->division);
        if (target > p->pcmFrames) target = p->pcmFrames;
        if (target > outPos) {
            int n = (int)(target - outPos);
            if (g_fl_synth) {
                /* FluidLite renders straight into our int16 frame buffer. */
                fluid_synth_write_s16(g_fl_synth, n,
                                      p->pcm + outPos, 0, p->channels,
                                      p->pcm + outPos, 0, p->channels);
            } else {
                midi_synth(ms->voices, p->pcm + outPos, n);
            }
            outPos = (int)target;
        }
        ms->curTick = e->tick;
        ms->ev_i++;""", """        int64_t due = (int64_t)(e->tick - ms->curTick) * ms->tempo * WAV_PCM_RATE /
                      (1000000LL * ms->division) - ms->since;
        if (due > 0) {
            int n = (due > p->pcmFrames - outPos) ? p->pcmFrames - outPos : (int)due;
            if (g_fl_synth) {
                /* stereo in un buffer temporaneo, poi media L/R nel PCM mono */
                static int16_t st[2 * 512];
                int done_n = 0;
                while (done_n < n) {
                    int k = n - done_n > 512 ? 512 : n - done_n, s;
                    fluid_synth_write_s16(g_fl_synth, k, st, 0, 2, st, 1, 2);
                    for (s = 0; s < k; s++)
                        p->pcm[outPos + done_n + s] = (int16_t)(((int)st[2 * s] + (int)st[2 * s + 1]) / 2);
                    done_n += k;
                }
            } else {
                midi_synth(ms->voices, p->pcm + outPos, n);
            }
            outPos += n;
            ms->since += n;
            if (n < due)
                break; /* blocco pieno: l'evento aspetta il prossimo blocco */
        }
        ms->curTick = e->tick;
        ms->since = 0;
        ms->ev_i++;""")
replace_block("pspkvm/platform_gb300/audio.c", """    if (ms->ev_i >= ms->nev) ms->done = 1;
    return 1;
}""", """    if (ms->ev_i >= ms->nev) {
        ms->done = 1;
        if (outPos < p->pcmFrames) { /* niente silenzio non sintetizzato in coda */
            g_wav_pcm_total -= (p->pcmFrames - outPos) * p->channels * 2;
            p->pcmFrames = outPos;
        }
    }
    return 1;
}""")

# 15) Mixer: per ogni campione audio (22050 al secondo) scorreva tutti i 64 posti
#     dei player. Ora la lista di quelli che suonano si fa una volta per blocco.
#     Su PC era ~10% di tutto il lavoro in partita.
replace_block("pspkvm/platform_gb300/audio.c", """static void wav_mix_frame(int32_t *l, int32_t *r) {
    int i;
    for (i = 0; i < WAV_MAX_PLAYERS; i++) {
        wav_player_t *p = &g_wav[i];""", """static wav_player_t *g_mix_list[WAV_MAX_PLAYERS]; /* 3DS: player che suonano */
static int g_mix_n = 0;

static void wav_mix_frame(int32_t *l, int32_t *r) {
    int i;
    for (i = 0; i < g_mix_n; i++) {
        wav_player_t *p = g_mix_list[i];""")
replace_block("pspkvm/platform_gb300/audio.c", """    wav_topup_midi();
""", """    wav_topup_midi();

    g_mix_n = 0;
    {
        int k;
        for (k = 0; k < WAV_MAX_PLAYERS; k++)
            if (g_wav[k].used && g_wav[k].playing && !g_wav[k].paused && g_wav[k].pcm)
                g_mix_list[g_mix_n++] = &g_wav[k];
    }
""")

# 16) Ciclo dell'interprete: il contatore per controllare input/timer ogni 2048
#     istruzioni era una variabile statica (lettura e scrittura in memoria a ogni
#     istruzione Java). Ora e' un conto alla rovescia locale, che sta in un registro.
replace_block("pspkvm/cldc/src/vm/cpu/c/Interpreter_c.cpp", """    static unsigned int bc_counter = 0;
    for (;;) {
      if ((++bc_counter & 0x7FF) == 0) {
        gb300_poll_events();
      }""", """    unsigned int bc_countdown = 0x800;
    for (;;) {
      if (--bc_countdown == 0) {
        bc_countdown = 0x800;
        gb300_poll_events();
      }""")

# 17) Fine brano. Il core faceva ripartire da solo OGNI brano MIDI, anche gli effetti
#     sonori: per esempio il suono di una cassa aperta continuava all'infinito.
#     Ora a fine brano il player avvisa Java con END_OF_MEDIA, come su un telefono
#     vero, e si ferma: e' Java (setLoopCount) a decidere se ripartire.
#     Diamond Rush non chiama mai setLoopCount: ogni suono, musica del titolo
#     compresa, suona una volta. Il gestore audio del gioco (classe j) aspetta proprio
#     "endOfMedia" per segnare il suono come finito; senza l'evento restava "in
#     corso" e i suoni con priorita' piu' bassa venivano scartati.
#     L'evento si mette in coda dal mixer e si consegna in midp_check_events(), il
#     punto in cui la VM riceve anche i tasti. Con il punto 19 parte alla fine
#     dell'ultima nota, mentre la coda del suono continua a sentirsi.
AUDIO = "pspkvm/platform_gb300/audio.c"
replace_block(AUDIO, """    void *midi;              /* midi_stream_t while streaming a SMF track */
    int loopMidi;            /* loop the rendered prefix instead of stopping */
} wav_player_t;""", """    void *midi;              /* midi_stream_t while streaming a SMF track */
    int loopMidi;            /* loop the rendered prefix instead of stopping */
    int pid, isolate;        /* 3DS: id del Player Java, per END_OF_MEDIA */
    int eomAt, eomSent;      /* 3DS: campione dell'END_OF_MEDIA, gia' inviato */
} wav_player_t;""")
replace_block(AUDIO, """    int looped;              /* one loop of the track has been rendered */
""", """    int looped;              /* one loop of the track has been rendered */
    int eom_frame;           /* 3DS: campione di fine traccia (0 = non ancora) */
""")
replace_block(AUDIO, """        g_wav[h].used = 1;
        g_wav[h].volume = 100;""", """        g_wav[h].used = 1;
        g_wav[h].volume = 100;
        g_wav[h].pid = pID;
        g_wav[h].isolate = isolateId;""")
replace_block(AUDIO, """static wav_player_t *g_mix_list[WAV_MAX_PLAYERS]; /* 3DS: player che suonano */
static int g_mix_n = 0;
""", """static wav_player_t *g_mix_list[WAV_MAX_PLAYERS]; /* 3DS: player che suonano */
static int g_mix_n = 0;

/* 3DS: END_OF_MEDIA in attesa di essere consegnati a Java */
#define FROGGY_EOM_MAX WAV_MAX_PLAYERS
#define FROGGY_NO_EOM 0x7FFFFFFF
static struct { int pid, isolate, ms; } g_eom[FROGGY_EOM_MAX];
static int g_eom_n = 0;

static void wav_end_of_media(wav_player_t *p) {
    p->eomSent = 1;
    p->eomAt = FROGGY_NO_EOM;
    if (g_eom_n < FROGGY_EOM_MAX) {
        g_eom[g_eom_n].pid = p->pid;
        g_eom[g_eom_n].isolate = p->isolate;
        g_eom[g_eom_n].ms = (int)(((int64_t)p->pos * 1000) / WAV_PCM_RATE);
        g_eom_n++;
    }
}

/* 3DS: campione a cui mandare END_OF_MEDIA (WAV: l'ultimo; MIDI: fine traccia) */
static int wav_eom_at(wav_player_t *p) {
    if (p->eomSent) return FROGGY_NO_EOM;
    if (!p->midi) return p->pcmFrames;
    return ((midi_stream_t *)p->midi)->eom_frame ? ((midi_stream_t *)p->midi)->eom_frame : FROGGY_NO_EOM;
}

/* 3DS: il player riparte o viene fermato: un END_OF_MEDIA non ancora consegnato e'
 * vecchio. Arrivando dopo, il gioco lo prenderebbe per la fine del suono successivo. */
static void wav_drop_eom(wav_player_t *p) {
    int i, j = 0;
    for (i = 0; i < g_eom_n; i++)
        if (g_eom[i].pid != p->pid || g_eom[i].isolate != p->isolate)
            g_eom[j++] = g_eom[i];
    g_eom_n = j;
}

/* Chiamata da midp_check_events(), nel thread della VM. */
void froggy_audio_post_events(void) {
    int i;
    for (i = 0; i < g_eom_n; i++) {
        MidpEvent e;
        MIDP_EVENT_INITIALIZE(e);
        e.type = MMAPI_EVENT;
        e.MM_PLAYER_ID = g_eom[i].pid;
        e.MM_DATA = g_eom[i].ms;
        e.MM_ISOLATE = g_eom[i].isolate;
        e.MM_EVT_TYPE = 1; /* END_OF_MEDIA in com.sun.mmedia.MMEventListener */
        StoreMIDPEventInVmThread(e, g_eom[i].isolate);
    }
    g_eom_n = 0;
}
""")
replace_block(AUDIO, """        if (p->pos >= p->pcmFrames) {
            if (p->midi && p->loopMidi) {
                p->pos = 0;              /* seamless loop */
            } else {
                p->playing = 0;
                p->pos = 0;
                continue;
            }
        }""", """        if (p->pos >= p->pcmFrames) {
            if (p->midi && !((midi_stream_t *)p->midi)->done)
                continue;                /* 3DS: PCM non ancora pronto: aspetta */
            if (!p->eomSent)
                wav_end_of_media(p);     /* 3DS: fine brano, decide Java */
            p->playing = 0;
            p->pos = 0;
            continue;
        }""")
replace_block(AUDIO, """            if (!p->midi && p->pos >= p->pcmFrames) {
                p->playing = 0;
                p->pos = 0;
            }""", """            if (p->pos >= p->eomAt)
                wav_end_of_media(p);     /* 3DS: fine traccia; la coda continua */""")
replace_block(AUDIO, """            if (g_wav[k].used && g_wav[k].playing && !g_wav[k].paused && g_wav[k].pcm)
                g_mix_list[g_mix_n++] = &g_wav[k];""", """            if (g_wav[k].used && g_wav[k].playing && !g_wav[k].paused && g_wav[k].pcm) {
                g_wav[k].eomAt = wav_eom_at(&g_wav[k]);
                g_mix_list[g_mix_n++] = &g_wav[k];
            }""")
replace_block(AUDIO, """        if (p->paused) {
            p->paused = 0;
        } else {
            p->pos = 0;
        }
        p->playing = 1;""", """        if (p->paused) {
            p->paused = 0;
        } else {
            p->pos = 0;
            p->eomSent = 0;   /* 3DS: nuova partenza, nuovo END_OF_MEDIA */
            wav_drop_eom(p);
        }
        p->playing = 1;""")
replace_block(AUDIO, """#include "fluidlite.h"
""", """#include "fluidlite.h"
#include "midpEvents.h"
""")
replace_block("pspkvm/midp/src/events/eventsystem/mastermode/native/midp_master_mode_events.c",
              """    newSignal.waitingFor = 0;
    newSignal.pResult = NULL;
    MIDP_EVENT_INITIALIZE(newMidpEvent);
""", """    {   /* 3DS: fine dei brani audio (platform_gb300/audio.c) */
        extern void froggy_audio_post_events(void);
        froggy_audio_post_events();
    }

    newSignal.waitingFor = 0;
    newSignal.pResult = NULL;
    MIDP_EVENT_INITIALIZE(newMidpEvent);
""")

# 18) Un sintetizzatore per brano. Tutti i player MIDI suonavano nello stesso
#     sintetizzatore: nel PCM di un brano finivano anche le note degli altri (per
#     esempio pezzi di un effetto sonoro dentro la musica).
#     Ora ogni brano ha il suo sintetizzatore FluidLite, che condivide il SoundFont
#     gia' caricato (niente memoria in piu' per i campioni) e viene liberato quando
#     il brano e' tutto sintetizzato.
replace_block(AUDIO, """static fluid_synth_t     *g_fl_synth = NULL;
static int                g_fl_probed = 0;""", """static fluid_synth_t     *g_fl_synth = NULL;
static int                g_fl_probed = 0;
static fluid_sfont_t     *g_fl_sfont = NULL; /* 3DS: SoundFont caricato una volta, condiviso */""")
replace_block(AUDIO, """            fluid_synth_set_interp_method(g_fl_synth, -1, FLUID_INTERP_LINEAR);
            return g_fl_synth;""", """            fluid_synth_set_interp_method(g_fl_synth, -1, FLUID_INTERP_LINEAR);
            g_fl_sfont = fluid_synth_get_sfont(g_fl_synth, 0);
            return g_fl_synth;""")
replace_block(AUDIO, """    int64_t since;               /* 3DS: campioni gia' sintetizzati dopo curTick */
};
/* 3DS: spegne nel sintetizzatore condiviso le note ancora accese da questo brano */
static void midi_fl_release(midi_stream_t *ms) {
    int ch, n;
    if (!ms || !g_fl_synth) return;
    for (ch = 0; ch < 16; ch++)
        for (n = 0; n < 128; n++)
            if (ms->fl_on[ch][n >> 3] & (1u << (n & 7)))
                fluid_synth_noteoff(g_fl_synth, ch, n);
    memset(ms->fl_on, 0, sizeof(ms->fl_on));
}
static void midi_stream_free(midi_stream_t *ms) {
    if (!ms) return;
    midi_fl_release(ms);""", """    int64_t since;               /* 3DS: campioni gia' sintetizzati dopo curTick */
    fluid_synth_t *fl;           /* 3DS: sintetizzatore di questo brano */
};
static fluid_synth_t *midi_stream_synth(midi_stream_t *ms) {
    if (!g_fl_synth || !g_fl_sfont) return NULL;
    if (!ms->fl) {
        ms->fl = new_fluid_synth(g_fl_settings);
        if (!ms->fl) return NULL;
        fluid_synth_add_sfont(ms->fl, g_fl_sfont);
        fluid_synth_set_interp_method(ms->fl, -1, FLUID_INTERP_LINEAR);
    }
    return ms->fl;
}
static void midi_stream_synth_free(midi_stream_t *ms) {
    if (ms && ms->fl) {
        fluid_synth_remove_sfont(ms->fl, g_fl_sfont); /* il SoundFont resta al synth principale */
        delete_fluid_synth(ms->fl);
        ms->fl = NULL;
    }
}
static void midi_stream_free(midi_stream_t *ms) {
    if (!ms) return;
    midi_stream_synth_free(ms);""")
RENDER = "static int midi_stream_render(wav_player_t *p, int frames) {"
replace_in_function(AUDIO, RENDER, """    if (!ms || frames <= 0) return 0;
""", """    if (!ms || frames <= 0) return 0;
    fluid_synth_t *fs = midi_stream_synth(ms); /* 3DS: synth di questo brano */
""", 1)
replace_in_function(AUDIO, RENDER, "if (g_fl_synth) {", "if (fs) {", 5)
replace_in_function(AUDIO, RENDER, "(g_fl_synth,", "(fs,", 5)
replace_in_function(AUDIO, RENDER, """            g_wav_pcm_total -= (p->pcmFrames - outPos) * p->channels * 2;
            p->pcmFrames = outPos;
        }""", """            g_wav_pcm_total -= (p->pcmFrames - outPos) * p->channels * 2;
            p->pcmFrames = outPos;
        }
        midi_stream_synth_free(ms); /* brano tutto sintetizzato: il synth non serve piu' */""", 1)
# Togliere il SoundFont da un synth fa ripartire i programmi dei 16 canali e
# FluidLite scrive un avviso per ognuno ("No preset found"): avvisi spenti.
replace_block(AUDIO, """static fluid_synth_t *midi_fluid_synth(void) {
    int i;
    if (g_fl_probed) return g_fl_synth;
    g_fl_probed = 1;
""", """static void froggy_fl_nolog(int level, char *message, void *data) {
    (void)level; (void)message; (void)data;
}

static fluid_synth_t *midi_fluid_synth(void) {
    int i;
    if (g_fl_probed) return g_fl_synth;
    g_fl_probed = 1;
    fluid_set_log_function(FLUID_WARN, froggy_fl_nolog, NULL); /* 3DS */
""")

# 19) Coda dei suoni e suoni interrotti.
#     - Dopo l'ultima nota il brano veniva tagliato di netto: molti effetti finiscono
#       mentre le note suonano ancora (uno degli effetti brevi del gioco dura 0,23 s
#       di note e 2 s di risonanza; al taglio era ancora al 46% del volume: un click).
#       Ora si sintetizza anche la coda, finche' scende sotto -54 dB (al massimo 3 s),
#       con una breve dissolvenza. END_OF_MEDIA parte alla fine dell'ultima nota.
#     - Brano fermato da Java: le sue note venivano spente (serviva col synth unico).
#       Col synth per brano (punto 18) non serve, e spegnerle troncava le note quando
#       il brano ripartiva e la sintesi riprendeva da dove era arrivata.
#     - Memoria PCM finita: il brano restava "in corso" per sempre; ora finisce li'.
replace_block(AUDIO, """    int eom_frame;           /* 3DS: campione di fine traccia (0 = non ancora) */
""", """    int eom_frame;           /* 3DS: campione di fine traccia (0 = non ancora) */
    int tail, tail_end;      /* 3DS: campioni di coda sintetizzati, coda finita */
""")
replace_block(AUDIO, """static int midi_stream_render(wav_player_t *p, int frames);
""", """static int midi_stream_render(wav_player_t *p, int frames);

/* 3DS: la sintesi del brano finisce qui (anche se mancano eventi) */
static void midi_stream_finish(midi_stream_t *ms, int endFrame) {
    if (!ms->eom_frame) ms->eom_frame = endFrame > 0 ? endFrame : 1;
    ms->done = 1;
    midi_stream_synth_free(ms);
}

#define MIDI_TAIL_MAX   (WAV_PCM_RATE * 3) /* 3DS: coda massima dopo l'ultima nota */
#define MIDI_TAIL_FLOOR 64                 /* 3DS: -54 dB: sotto questo la coda finisce */
""")
replace_in_function(AUDIO, RENDER, """    if (want <= p->pcmFrames) return 0;                    /* out of PCM budget */
    if (want > WAV_PCM_RATE * 300) want = WAV_PCM_RATE * 300;   /* 5 min cap */

    {
        int16_t *np = (int16_t *)realloc(p->pcm, (size_t)want * 2);
        if (!np) return 0;
        p->pcm = np;
    }""", """    if (want > WAV_PCM_RATE * 300) want = WAV_PCM_RATE * 300;   /* 5 min cap */
    if (want <= p->pcmFrames) {               /* 3DS: memoria o durata finite: */
        midi_stream_finish(ms, p->pcmFrames); /* il brano termina qui */
        return 0;
    }

    {
        int16_t *np = (int16_t *)realloc(p->pcm, (size_t)want * 2);
        if (!np) { midi_stream_finish(ms, p->pcmFrames); return 0; }
        p->pcm = np;
    }""", 1)
replace_in_function(AUDIO, RENDER, """    if (ms->ev_i >= ms->nev) {
        ms->done = 1;""", """    if (ms->ev_i >= ms->nev) {
        if (!ms->eom_frame)
            ms->eom_frame = outPos > 0 ? outPos : 1; /* 3DS: fine traccia */
        /* 3DS: coda: le note gia' rilasciate finiscono di suonare */
        while (fs && !ms->tail_end && outPos < p->pcmFrames) {
            static int16_t tst[2 * 256];
            int k = p->pcmFrames - outPos, s, peak = 0;
            if (k > 256) k = 256;
            fluid_synth_write_s16(fs, k, tst, 0, 2, tst, 1, 2);
            for (s = 0; s < k; s++) {
                int v = ((int)tst[2 * s] + (int)tst[2 * s + 1]) / 2;
                p->pcm[outPos + s] = (int16_t)v;
                if (v < 0) v = -v;
                if (v > peak) peak = v;
            }
            outPos += k;
            ms->tail += k;
            if (peak < MIDI_TAIL_FLOOR || ms->tail >= MIDI_TAIL_MAX ||
                fluid_synth_get_active_voice_count(fs) == 0) {
                for (s = 0; s < k; s++) /* dissolvenza sull'ultimo blocco: niente click */
                    p->pcm[outPos - k + s] = (int16_t)((int)p->pcm[outPos - k + s] * (k - s) / k);
                ms->tail_end = 1;
            }
        }
        if (fs && !ms->tail_end)
            return 1;                 /* 3DS: la coda continua al prossimo blocco */
        ms->done = 1;""", 1)
replace_block(AUDIO, """        p->pos = 0;
        if (p->midi) midi_fl_release((midi_stream_t *)p->midi);""", """        p->pos = 0;
        wav_drop_eom(p);  /* 3DS: fermato da Java: niente END_OF_MEDIA in ritardo */
        /* 3DS: niente note da spegnere: il brano ha il suo synth, fermo al punto in cui
         * la sintesi era arrivata. Alla prossima partenza si risente il PCM gia' pronto e
         * la sintesi riprende da li', senza rifare il lavoro gia' fatto. */""")

# 20) Interprete Java sul 3DS: i suoi tre registri piu' usati (pc, cima dello stack,
#     variabili locali) stavano in memoria. Ogni istruzione Java li rileggeva e
#     riscriveva: su ARM 3 istruzioni in piu' solo per prendere gli indirizzi, piu'
#     letture e scritture. Ora stanno fissi nei registri r8-r10 della CPU, riservati
#     nel core con -ffixed-r8/r9/r10: nessun'altra funzione del core li usa; le
#     librerie esterne li salvano e li ripristinano, come vuole l'ABI ARM.
#     Fanno eccezione grafica J2ME e FluidLite, librerie "foglia" che non richiamano
#     mai l'interprete: con 3 registri in meno i loro cicli diventavano piu' lenti.
#     Le chiamate dall'interprete alla VM salvano gia' tutto nella struttura del
#     thread e lo ricaricano al ritorno (shared_call_vm_internal/resume_thread);
#     l'interprete esce sempre con longjmp, che rimette i registri del chiamante.
#     Misurato con qemu-arm sul codice ARM del 3DS: -30% istruzioni nell'interprete,
#     circa -20% per fotogramma in partita.
replace_line("Makefile", "    STATIC_LINKING = 1", [
    "    STATIC_LINKING = 1",
    "    FROGGY_FIXED = -DFROGGY_ARM_REGS -ffixed-r8 -ffixed-r9 -ffixed-r10",
    "    FROGGY_NOFIX = pspkvm/platform_gb300/fluidlite/% pspkvm/midp/src/lowlevelui/%",
], first=True)
replace_line("Makefile", "\t$(CC) $(CFLAGS) -c $< -o $@", [
    "\t$(CC) $(CFLAGS) $(if $(filter $(FROGGY_NOFIX),$<),,$(FROGGY_FIXED)) -c $< -o $@",
], exact=True)
replace_line("Makefile", "\t$(CXX) $(CXXFLAGS) -c $< -o $@", [
    "\t$(CXX) $(CXXFLAGS) $(if $(filter $(FROGGY_NOFIX),$<),,$(FROGGY_FIXED)) -c $< -o $@",
], exact=True)
replace_block("pspkvm/cldc/src/vm/cpu/c/Interpreter_c.cpp", """  /* global VM pointers */
  static address  g_jfp;     /* Java frame pointer   */
  static address  g_jsp;     /* Java stack pointer   */
  static address  g_jpc;     /* Java program counter */
  static address  g_jlocals; /* current Java method locals pointer */
""", """  /* global VM pointers */
#if defined(__arm__) && defined(FROGGY_ARM_REGS)
  /* 3DS: registri della CPU riservati con -ffixed-r8/r9/r10 (port/patch_core.py, 20) */
  register address g_jsp     asm("r8");  /* Java stack pointer   */
  register address g_jpc     asm("r9");  /* Java program counter */
  register address g_jlocals asm("r10"); /* current Java method locals pointer */
  static address  g_jfp;     /* Java frame pointer   */
#else
  static address  g_jfp;     /* Java frame pointer   */
  static address  g_jsp;     /* Java stack pointer   */
  static address  g_jpc;     /* Java program counter */
  static address  g_jlocals; /* current Java method locals pointer */
#endif
""")

# 21) Audio a blocchi e sintesi piu' regolare.
#     - Il mixer lavorava un campione alla volta: per ognuno una chiamata, il giro di
#       tutti i player e i controlli. Ora mescola un blocco intero per player e, se
#       non suona niente, scrive solo silenzio.
#     - La sintesi MIDI preparava fino a 4096 campioni (0,19 s) per volta, finche' il
#       brano non era 2 s avanti: quando partiva un suono nuovo il gioco si fermava per
#       qualche fotogramma (sull'Old 3DS un blocco costava ~45 ms). Ora 1024 per volta
#       (2048 se il PCM pronto sta per finire) e 1 s di anticipo: lo stesso lavoro,
#       distribuito su piu' fotogrammi.
replace_block(AUDIO, """#define MIDI_TOPUP_MAX 4096""", """#define MIDI_TOPUP_MAX 1024    /* 3DS: blocchi piccoli, niente scatti (punto 21) */
#define MIDI_TOPUP_URGENT 2048 /* 3DS: quando il PCM pronto sta per finire */
#define MIDI_LEAD (WAV_PCM_RATE * 1) /* 3DS: anticipo della sintesi sulla riproduzione */""")
replace_block(AUDIO, """            if (remaining < WAV_PCM_RATE * 2) {
                int deficit = WAV_PCM_RATE * 2 - remaining;
                int chunk = (deficit > MIDI_TOPUP_MAX) ? MIDI_TOPUP_MAX : deficit;""", """            if (remaining < MIDI_LEAD) {
                int deficit = MIDI_LEAD - remaining;
                int cap = remaining < WAV_PCM_RATE / 8 ? MIDI_TOPUP_URGENT : MIDI_TOPUP_MAX;
                int chunk = (deficit > cap) ? cap : deficit;""")
replace_block(AUDIO, """static void wav_mix_frame(int32_t *l, int32_t *r) {
    int i;
    for (i = 0; i < g_mix_n; i++) {
        wav_player_t *p = g_mix_list[i];
        if (!p->used || !p->playing || p->paused || !p->pcm) continue;

        if (p->pos >= p->pcmFrames) {
            if (p->midi && !((midi_stream_t *)p->midi)->done)
                continue;                /* 3DS: PCM non ancora pronto: aspetta */
            if (!p->eomSent)
                wav_end_of_media(p);     /* 3DS: fine brano, decide Java */
            p->playing = 0;
            p->pos = 0;
            continue;
        }

        if (p->pos < p->pcmFrames) {
            int vol = p->muted ? 0 : p->volume;
            int sl = p->pcm[p->pos * p->channels];
            int sr = (p->channels > 1) ? p->pcm[p->pos * p->channels + 1] : sl;
            *l += (sl * vol) / 100;
            *r += (sr * vol) / 100;
            p->pos++;
            if (p->pos >= p->eomAt)
                wav_end_of_media(p);     /* 3DS: fine traccia; la coda continua */
        }
    }
}
""", """/* 3DS: mescola n campioni di un player in acc (stereo, 32 bit) */
static void wav_mix_block(wav_player_t *p, int32_t *acc, int n) {
    int i = 0;
    while (i < n) {
        int run, k, vol, vq;
        const int16_t *src;
        if (!p->used || !p->playing || p->paused || !p->pcm) return;
        if (p->pos >= p->pcmFrames) {
            if (p->midi && !((midi_stream_t *)p->midi)->done && !froggy_midi_off)
                return;                  /* 3DS: PCM non ancora pronto: aspetta */
            /* (con l'audio muto la sintesi e' ferma: il brano finisce qui, invece di
             * restare "in corso" e partire in ritardo quando si riattiva l'audio) */
            if (!p->eomSent)
                wav_end_of_media(p);     /* 3DS: fine brano, decide Java */
            p->playing = 0;
            p->pos = 0;
            return;
        }
        run = p->pcmFrames - p->pos;
        if (run > n - i) run = n - i;
        if (p->eomAt > p->pos && p->eomAt - p->pos < run)
            run = p->eomAt - p->pos;     /* fermati esattamente a fine traccia */
        vol = p->muted ? 0 : p->volume;
        if (vol < 0) vol = 0;
        if (vol > 100) vol = 100;
        vq = (vol * 65536 + 50) / 100;   /* volume in 16.16 */
        src = p->pcm + p->pos * p->channels;
        if (vq == 65536) {
            if (p->channels == 1)
                for (k = 0; k < run; k++) { int v = src[k]; acc[2 * (i + k)] += v; acc[2 * (i + k) + 1] += v; }
            else
                for (k = 0; k < run; k++) { acc[2 * (i + k)] += src[2 * k]; acc[2 * (i + k) + 1] += src[2 * k + 1]; }
        } else if (vq) {
            if (p->channels == 1)
                for (k = 0; k < run; k++) { int v = (src[k] * vq) >> 16; acc[2 * (i + k)] += v; acc[2 * (i + k) + 1] += v; }
            else
                for (k = 0; k < run; k++) {
                    acc[2 * (i + k)] += (src[2 * k] * vq) >> 16;
                    acc[2 * (i + k) + 1] += (src[2 * k + 1] * vq) >> 16;
                }
        }
        p->pos += run;
        i += run;
        if (p->pos >= p->eomAt)
            wav_end_of_media(p);         /* 3DS: fine traccia; la coda continua */
    }
}
""")
replace_block(AUDIO, """    for (int i = 0; i < num_frames; i++) {
        int32_t mix_l = 0;
        int32_t mix_r = 0;

        // Take from ring buffer if available
        if (audio_buffer_tail != audio_buffer_head) {
            mix_l += audio_ring_buffer[audio_buffer_tail];
            audio_buffer_tail = (audio_buffer_tail + 1) & AUDIO_RING_MASK;
            mix_r += audio_ring_buffer[audio_buffer_tail];
            audio_buffer_tail = (audio_buffer_tail + 1) & AUDIO_RING_MASK;
        }

        // Mix synthesized tone (smooth triangle wave)
        if (g_tone.active && g_tone.samples_remaining > 0) {""", """    /* 3DS: a blocchi di 256 campioni (punto 21) */
    for (int done = 0; done < num_frames; ) {
        static int32_t acc[2 * 256];
        int n = num_frames - done, i, k;
        int16_t *out = dst + done * 2;
        if (n > 256) n = 256;
        done += n;
        if (g_mix_n == 0 && audio_buffer_tail == audio_buffer_head && !g_tone.active) {
            memset(out, 0, (size_t)n * 2 * sizeof(int16_t)); /* niente da suonare */
            continue;
        }
        memset(acc, 0, (size_t)n * 2 * sizeof(int32_t));
        for (i = 0; i < n && (audio_buffer_tail != audio_buffer_head ||
                              (g_tone.active && g_tone.samples_remaining > 0)); i++) {
        int32_t mix_l = 0;
        int32_t mix_r = 0;

        // Take from ring buffer if available
        if (audio_buffer_tail != audio_buffer_head) {
            mix_l += audio_ring_buffer[audio_buffer_tail];
            audio_buffer_tail = (audio_buffer_tail + 1) & AUDIO_RING_MASK;
            mix_r += audio_ring_buffer[audio_buffer_tail];
            audio_buffer_tail = (audio_buffer_tail + 1) & AUDIO_RING_MASK;
        }

        // Mix synthesized tone (smooth triangle wave)
        if (g_tone.active && g_tone.samples_remaining > 0) {""")
replace_block(AUDIO, """        // Mix WAV players (JSR-135 DirectPlayer)
        wav_mix_frame(&mix_l, &mix_r);

        if (mix_l > 32767) mix_l = 32767; else if (mix_l < -32768) mix_l = -32768;
        if (mix_r > 32767) mix_r = 32767; else if (mix_r < -32768) mix_r = -32768;
        dst[i * 2] = (int16_t)mix_l;
        dst[i * 2 + 1] = (int16_t)mix_r;
    }
    return num_frames;
}""", """        acc[2 * i] += mix_l;
        acc[2 * i + 1] += mix_r;
        }

        // Mix WAV players (JSR-135 DirectPlayer)
        for (k = 0; k < g_mix_n; k++)
            wav_mix_block(g_mix_list[k], acc, n);

        for (i = 0; i < n; i++) {
            int32_t mix_l = acc[2 * i], mix_r = acc[2 * i + 1];
            if (mix_l > 32767) mix_l = 32767; else if (mix_l < -32768) mix_l = -32768;
            if (mix_r > 32767) mix_r = 32767; else if (mix_r < -32768) mix_r = -32768;
            out[i * 2] = (int16_t)mix_l;
            out[i * 2 + 1] = (int16_t)mix_r;
        }
    }
    return num_frames;
}""")

# 22) FluidLite in virgola mobile a 32 bit sul 3DS. FroggyKVM usava i double perche'
#     sull'SF2000 (MIPS senza FPU) costavano meno delle conversioni; il VFP dell'ARM11
#     invece fa le moltiplicazioni float in meta' tempo dei double e i buffer pesano
#     la meta'. Su PC il risultato coincide con quello in double entro ~-60/-75 dB
#     (salvo quale nota viene tolta quando le 32 voci sono tutte occupate).
replace_block("pspkvm/platform_gb300/fluidlite/fluid_config.h", """#define HAVE_STRING_H 1""", """#if defined(__3DS__) || defined(FROGGY_FL_FLOAT)
#define WITH_FLOAT /* 3DS: VFP, float piu' veloce dei double (port/patch_core.py, 22) */
#endif
#define HAVE_STRING_H 1""")

print("[patch] tutte le modifiche applicate")
