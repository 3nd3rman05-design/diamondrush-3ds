#!/usr/bin/env python3
# Diamond Rush 3DS - modifiche al sorgente di FroggyKVM per il 3DS (ARM11 + percorsi).
# Uso: python3 port/patch_core.py <cartella-froggykvm>
# Ogni modifica verifica di trovare esattamente il testo atteso: se il sorgente
# cambia, lo script si ferma invece di produrre una build sbagliata.
import pathlib
import sys

ROOT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "froggykvm")


def load(rel):
    data = (ROOT / rel).read_bytes().decode("latin-1")
    return data.splitlines(keepends=True)


def save(rel, lines):
    (ROOT / rel).write_bytes("".join(lines).encode("latin-1"))


def eol_of(line):
    return "\r\n" if line.endswith("\r\n") else "\n"


def find_unique(lines, rel, needle, exact=False):
    hits = [i for i, l in enumerate(lines)
            if (l.rstrip("\r\n") == needle if exact else needle in l)]
    if len(hits) != 1:
        sys.exit(f"[patch] {rel}: attesa 1 riga con {needle!r}, trovate {len(hits)}")
    return hits[0]


def replace_line(rel, needle, new_lines, exact=False, first=False):
    lines = load(rel)
    if first:
        hits = [i for i, l in enumerate(lines)
                if (l.rstrip("\r\n") == needle if exact else needle in l)]
        if not hits:
            sys.exit(f"[patch] {rel}: riga {needle!r} non trovata")
        i = hits[0]
    else:
        i = find_unique(lines, rel, needle, exact)
    eol = eol_of(lines[i])
    lines[i:i + 1] = [t + eol for t in new_lines]
    save(rel, lines)
    print(f"[patch] ok  {rel}")


def replace_block(rel, old, new):
    """Sostituisce un blocco di piu' righe che deve comparire esattamente una volta."""
    data = (ROOT / rel).read_bytes().decode("latin-1")
    eol = "\r\n" if "\r\n" in data else "\n"
    old = old.replace("\n", eol)
    new = new.replace("\n", eol)
    n = data.count(old)
    if n != 1:
        sys.exit(f"[patch] {rel}: blocco atteso 1 volta, trovato {n} volte:\n{old}")
    (ROOT / rel).write_bytes(data.replace(old, new).encode("latin-1"))
    print(f"[patch] ok  {rel}")


def insert_before(rel, needle, new_lines):
    lines = load(rel)
    i = find_unique(lines, rel, needle)
    eol = eol_of(lines[i])
    lines[i:i] = [t + eol for t in new_lines]
    save(rel, lines)
    print(f"[patch] ok  {rel}")


# 1) Piattaforma "ctr" (3DS, ARM11) nel Makefile del core
replace_line("Makefile", "ifeq ($(platform), sf2000)", [
    "ifeq ($(platform), ctr)",
    "    TOOLPFX := $(if $(DEVKITARM),$(DEVKITARM)/bin/,)arm-none-eabi-",
    "    TARGET := $(NAME)_libretro_ctr.a",
    "    CC = $(TOOLPFX)gcc",
    "    CXX = $(TOOLPFX)g++",
    "    AR = $(TOOLPFX)ar",
    "    CTR_FLAGS = -march=armv6k -mtune=mpcore -mfloat-abi=hard -mfpu=vfp -mtp=soft -mword-relocations"
    " -fno-short-enums -ffunction-sections -fdata-sections -D__3DS__ -DARM11 -DNO_THREADS"
    " -DPSP_COMPAT -DPRODUCT=1 -DFROGGY_NATIVE_FRAME -DFROGGY_SD_ROOT=\\\"sdmc:/3ds/diamondrush\\\"",
    # devkitARM usa GCC 16: il C di default e' C23 e alcuni vecchi avvisi sono diventati errori.
    # Il codice phoneME/PSPKVM e' del 2008: si compila con gli standard per cui e' stato scritto.
    "    override CFLAGS += $(CTR_FLAGS) -std=gnu11 -Wno-incompatible-pointer-types"
    " -Wno-implicit-function-declaration -Wno-int-conversion",
    "    override CXXFLAGS += $(CTR_FLAGS) -std=gnu++14 -fno-exceptions -fno-rtti -fpermissive",
    "    STATIC_LINKING = 1",
    "else ifeq ($(platform), sf2000)",
], exact=True, first=True)

# 2) ARM AAPCS: va_list e' una struct, non si puo' passare NULL
replace_line("pspkvm/cldc/src/vm/cpu/c/Interpreter_c.cpp",
             "invoke_native_entry(native_ptr, return_type, 0, NULL, r1, r2);", [
    "    { va_list no_args; memset(&no_args, 0, sizeof(no_args));"
    " invoke_native_entry(native_ptr, return_type, 0, no_args, r1, r2); }",
])

# 3) Breakpoint: il fallback usava un'istruzione x86 ("int $03")
replace_line("pspkvm/cldc/src/vm/share/utilities/GlobalDefinitions_gcc.hpp",
             '#  define panic() __asm__ ("break")', [
    '#  define panic() __asm__ ("break")',
    "#elif defined(__arm__)",
    "#  define BREAKPOINT __builtin_trap()",
    "#  define panic() __builtin_trap()",
], exact=True)

# 4) classes.zip dentro la RomFS della CIA (controllo di esistenza + classpath reale)
insert_before("pspkvm/platform_gb300/platform.c",
              'FROGGY_SD_ROOT "/cubegm/bios/classes.zip",',
              ['        "romfs:/classes.zip",'])
insert_before("pspkvm/cldc/src/vm/share/handles/Universe.cpp",
              'FROGGY_SD_ROOT "/cubegm/bios/classes.zip",',
              ['        "romfs:/classes.zip",'])

# 5) SoundFont: prima quello nella RomFS (TimGM6mb, GPL-2), poi uno personale sulla SD
insert_before("pspkvm/platform_gb300/audio.c",
              '"/mnt/sda1/bios/Roland_SC-55.sf2",',
              ['    "romfs:/TimGM6mb.sf2",',
               '    FROGGY_SD_ROOT "/music.sf2",'])

# 6) Salvataggi: FroggyKVM scrive in /mnt/sda1/system/saves (percorso dell'SF2000).
#    Sul 3DS vanno in sdmc:/3ds/diamondrush/saves.
replace_line("pspkvm/platform_gb300/rms_posix.c",
             'const char* custom = getenv("GB300_RMS_DIR");', [
    "#ifdef __3DS__",
    '        const char* custom = FROGGY_SD_ROOT "/saves";',
    "#else",
    '        const char* custom = getenv("GB300_RMS_DIR");',
    "#endif",
])

# 7) Frame nativo: consegna al frontend l'immagine J2ME senza ritagliarla a 320x240
insert_before("pspkvm/platform_gb300/video.c",
              "static int last_w = -1, last_h = -1;", [
    "#ifdef FROGGY_NATIVE_FRAME",
    "    {",
    "        retro_video_refresh_t native_vcb = gb300_get_video_cb();",
    "        if (native_vcb) native_vcb(src, src_w, src_h, src_pitch);",
    "        gb300_poll_events();",
    "        return;",
    "    }",
    "#endif",
])

# 8) MIDI con FluidLite: dopo ogni nota on/off l'indice dell'evento avanzava due volte,
#    saltando l'evento successivo (spesso il note-off). Insieme al punto 12: su PC
#    fino a 250 voci attive sul titolo, mentre il brano suona al massimo 24 note
#    insieme. Musica sbagliata e CPU sprecata: su PC la sintesi era circa il 60%
#    del lavoro sul titolo.
replace_block("pspkvm/platform_gb300/audio.c", """                fluid_synth_noteon(g_fl_synth, ch, note, vel);
                ms->curTick = e->tick;
                ms->ev_i++;
                continue;""", """                fluid_synth_noteon(g_fl_synth, ch, note, vel);
                continue;""")
replace_block("pspkvm/platform_gb300/audio.c", """                fluid_synth_noteoff(g_fl_synth, ch, note);
                ms->curTick = e->tick;
                ms->ev_i++;
                continue;""", """                fluid_synth_noteoff(g_fl_synth, ch, note);
                continue;""")

# 9) Brano MIDI in loop: invece di risintetizzarlo da capo a ogni giro (CPU) si
#    ripete il PCM gia' pronto. Prima, in piu', il conteggio della memoria PCM
#    cresceva a ogni giro senza mai scendere.
replace_block("pspkvm/platform_gb300/audio.c", """        if (ms && ms->done && remaining > 0 && remaining < WAV_PCM_RATE / 4) {
            if (p->loopMidi) {
                ms->ev_i = 0;
                ms->curTick = 0;
                ms->done = 0;
                ms->looped = 0;
                p->pcmFrames = 0;
                p->pos = 0;
                remaining = 0;
            }
        }""", """        /* 3DS: brano finito e in loop -> wav_mix_frame() riparte da pos 0
         * sul PCM gia' sintetizzato, senza risintetizzare. */""")

# 10) FluidLite piu' leggero: niente riverbero/chorus, interpolazione lineare,
#     massimo 32 voci. Sull'altoparlante del 3DS la differenza non si sente.
#     Guadagno 0.6 invece di 0.2: corrette le note bloccate (punti 8 e 12) la musica
#     risultava 7 volte piu' bassa di prima; cosi' il picco resta sotto i 2/3 del massimo.
replace_block("pspkvm/platform_gb300/audio.c", """    g_fl_settings = new_fluid_settings();
    if (!g_fl_settings) return NULL;""", """    g_fl_settings = new_fluid_settings();
    if (!g_fl_settings) return NULL;
    fluid_settings_setstr(g_fl_settings, "synth.reverb.active", "no");
    fluid_settings_setstr(g_fl_settings, "synth.chorus.active", "no");
    fluid_settings_setint(g_fl_settings, "synth.polyphony", 32);
    fluid_settings_setnum(g_fl_settings, "synth.gain", 0.6);""")
replace_block("pspkvm/platform_gb300/audio.c", """            xlog("[AUDIO] FluidLite: soundfont %s wczytany\\n", g_fl_soundfonts[i]);
            return g_fl_synth;""", """            xlog("[AUDIO] FluidLite: soundfont %s wczytany\\n", g_fl_soundfonts[i]);
            fluid_synth_set_interp_method(g_fl_synth, -1, FLUID_INTERP_LINEAR);
            return g_fl_synth;""")

# 11) Audio spento dal frontend: niente sintesi MIDI (la parte che costa).
#     Il frontend scrive froggy_midi_off = 1 quando l'audio e' muto.
replace_block("pspkvm/platform_gb300/audio.c", """static void wav_topup_midi(void) {
    int i;""", """int froggy_midi_off = 0;

static void wav_topup_midi(void) {
    int i;
    if (froggy_midi_off) return;""")

# 12) Note rimaste accese nel sintetizzatore condiviso. Il gioco crea all'avvio una
#     ventina di player MIDI (musiche ed effetti) e per ognuno il core sintetizzava
#     subito 512 campioni: le prime note partivano, i loro note-off no. Ora:
#     - il prefisso iniziale e' silenzio (la sintesi parte quando il brano suona);
#     - ogni brano ricorda le note che ha acceso e le spegne quando viene fermato
#       o chiuso.
replace_block("pspkvm/platform_gb300/audio.c", """    int done;                /* all events consumed */
    int looped;              /* one loop of the track has been rendered */
};
static void midi_stream_free(midi_stream_t *ms) {
    if (!ms) return;""", """    int done;                /* all events consumed */
    int looped;              /* one loop of the track has been rendered */
    unsigned char fl_on[16][16]; /* 3DS: note FluidLite accese da questo brano */
};
/* 3DS: spegne nel sintetizzatore condiviso le note ancora accese da questo brano */
static void midi_fl_release(midi_stream_t *ms) {
    int ch, n;
    if (!ms || !g_fl_synth) return;
    for (ch = 0; ch < 16; ch++)
        for (n = 0; n < 128; n++)
            if (ms->fl_on[ch][n >> 3] & (1u << (n & 7)))
                fluid_synth_noteoff(g_fl_synth, ch, n);
    memset(ms->fl_on, 0, sizeof(ms->fl_on));
}
static void midi_stream_free(midi_stream_t *ms) {
    if (!ms) return;
    midi_fl_release(ms);""")
replace_block("pspkvm/platform_gb300/audio.c", """                fluid_synth_noteon(g_fl_synth, ch, note, vel);
                continue;""", """                fluid_synth_noteon(g_fl_synth, ch, note, vel);
                ms->fl_on[ch][note >> 3] |= (unsigned char)(1u << (note & 7));
                continue;""")
replace_block("pspkvm/platform_gb300/audio.c", """                fluid_synth_noteoff(g_fl_synth, ch, note);
                continue;""", """                fluid_synth_noteoff(g_fl_synth, ch, note);
                ms->fl_on[ch][note >> 3] &= (unsigned char)~(1u << (note & 7));
                continue;""")
replace_block("pspkvm/platform_gb300/audio.c", """        if (prefix > 0) {
            midi_stream_render(p, prefix);""", """        if (prefix > 0) {
            int16_t *np = NULL;
            if (g_fl_synth) {
                /* 3DS: 64 campioni di silenzio (3 ms) senza toccare il synth condiviso */
                if (prefix > 64) prefix = 64;
                np = (int16_t *)realloc(p->pcm, (size_t)prefix * 2);
            }
            if (np) {
                memset(np, 0, (size_t)prefix * 2);
                p->pcm = np;
                g_wav_pcm_total += (prefix - p->pcmFrames) * 2;
                p->pcmFrames = prefix;
            } else {
                midi_stream_render(p, prefix);
            }""")
replace_block("pspkvm/platform_gb300/audio.c", """    if (p) {
        p->playing = 0;
        p->paused = 0;
        p->pos = 0;
    }""", """    if (p) {
        p->playing = 0;
        p->paused = 0;
        p->pos = 0;
        if (p->midi) midi_fl_release((midi_stream_t *)p->midi);
    }""")

# 13) SELECT+START insieme chiudeva il gioco all'istante (era il menu dell'SF2000).
#     Sul 3DS SELECT e START sono tasti del gioco: si esce solo da "Esci".
replace_line("pspkvm/platform_gb300/platform.c",
             "if ((buttons & (PSP_CTRL_SELECT | PSP_CTRL_START)) == (PSP_CTRL_SELECT | PSP_CTRL_START)) {", [
    "        if (0) { /* 3DS: combinazione d'uscita disattivata */",
])

# 14) Tempo della musica. Quando un evento cadeva oltre la fine del blocco da
#     sintetizzare, veniva eseguito subito e il tempo mancante si perdeva: la
#     musica andava 1,6-2 volte piu' veloce (titolo: 23,7 s suonati in ~11,5 s).
#     Ora l'evento resta in attesa e si conta quanto e' gia' stato sintetizzato.
#     In piu': mono = media di sinistra e destra (prima restava solo la destra) e
#     il brano finito viene tagliato all'ultimo evento, cosi' il loop non ha buchi.
replace_block("pspkvm/platform_gb300/audio.c", """    unsigned char fl_on[16][16]; /* 3DS: note FluidLite accese da questo brano */
};""", """    unsigned char fl_on[16][16]; /* 3DS: note FluidLite accese da questo brano */
    int64_t since;               /* 3DS: campioni gia' sintetizzati dopo curTick */
};""")
replace_block("pspkvm/platform_gb300/audio.c", """        int64_t target = outPos + (int64_t)(e->tick - ms->curTick) * ms->tempo * WAV_PCM_RATE /
                                   (1000000LL * ms->division);
        if (target > p->pcmFrames) target = p->pcmFrames;
        if (target > outPos) {
            int n = (int)(target - outPos);
            if (g_fl_synth) {
                /* FluidLite renders straight into our int16 frame buffer. */
                fluid_synth_write_s16(g_fl_synth, n,
                                      p->pcm + outPos, 0, p->channels,
                                      p->pcm + outPos, 0, p->channels);
            } else {
                midi_synth(ms->voices, p->pcm + outPos, n);
            }
            outPos = (int)target;
        }
        ms->curTick = e->tick;
        ms->ev_i++;""", """        int64_t due = (int64_t)(e->tick - ms->curTick) * ms->tempo * WAV_PCM_RATE /
                      (1000000LL * ms->division) - ms->since;
        if (due > 0) {
            int n = (due > p->pcmFrames - outPos) ? p->pcmFrames - outPos : (int)due;
            if (g_fl_synth) {
                /* stereo in un buffer temporaneo, poi media L/R nel PCM mono */
                static int16_t st[2 * 512];
                int done_n = 0;
                while (done_n < n) {
                    int k = n - done_n > 512 ? 512 : n - done_n, s;
                    fluid_synth_write_s16(g_fl_synth, k, st, 0, 2, st, 1, 2);
                    for (s = 0; s < k; s++)
                        p->pcm[outPos + done_n + s] = (int16_t)(((int)st[2 * s] + (int)st[2 * s + 1]) / 2);
                    done_n += k;
                }
            } else {
                midi_synth(ms->voices, p->pcm + outPos, n);
            }
            outPos += n;
            ms->since += n;
            if (n < due)
                break; /* blocco pieno: l'evento aspetta il prossimo blocco */
        }
        ms->curTick = e->tick;
        ms->since = 0;
        ms->ev_i++;""")
replace_block("pspkvm/platform_gb300/audio.c", """    if (ms->ev_i >= ms->nev) ms->done = 1;
    return 1;
}""", """    if (ms->ev_i >= ms->nev) {
        ms->done = 1;
        if (outPos < p->pcmFrames) { /* niente silenzio in coda: loop senza buchi */
            g_wav_pcm_total -= (p->pcmFrames - outPos) * p->channels * 2;
            p->pcmFrames = outPos;
        }
    }
    return 1;
}""")

# 15) Mixer: per ogni campione audio (22050 al secondo) scorreva tutti i 64 posti
#     dei player. Ora la lista di quelli che suonano si fa una volta per blocco.
#     Su PC era ~10% di tutto il lavoro in partita.
replace_block("pspkvm/platform_gb300/audio.c", """static void wav_mix_frame(int32_t *l, int32_t *r) {
    int i;
    for (i = 0; i < WAV_MAX_PLAYERS; i++) {
        wav_player_t *p = &g_wav[i];""", """static wav_player_t *g_mix_list[WAV_MAX_PLAYERS]; /* 3DS: player che suonano */
static int g_mix_n = 0;

static void wav_mix_frame(int32_t *l, int32_t *r) {
    int i;
    for (i = 0; i < g_mix_n; i++) {
        wav_player_t *p = g_mix_list[i];""")
replace_block("pspkvm/platform_gb300/audio.c", """    wav_topup_midi();
""", """    wav_topup_midi();

    g_mix_n = 0;
    {
        int k;
        for (k = 0; k < WAV_MAX_PLAYERS; k++)
            if (g_wav[k].used && g_wav[k].playing && !g_wav[k].paused && g_wav[k].pcm)
                g_mix_list[g_mix_n++] = &g_wav[k];
    }
""")

# 16) Ciclo dell'interprete: il contatore per controllare input/timer ogni 2048
#     istruzioni era una variabile statica (lettura e scrittura in memoria a ogni
#     istruzione Java). Ora e' un conto alla rovescia locale, che sta in un registro.
replace_block("pspkvm/cldc/src/vm/cpu/c/Interpreter_c.cpp", """    static unsigned int bc_counter = 0;
    for (;;) {
      if ((++bc_counter & 0x7FF) == 0) {
        gb300_poll_events();
      }""", """    unsigned int bc_countdown = 0x800;
    for (;;) {
      if (--bc_countdown == 0) {
        bc_countdown = 0x800;
        gb300_poll_events();
      }""")

print("[patch] tutte le modifiche applicate")
