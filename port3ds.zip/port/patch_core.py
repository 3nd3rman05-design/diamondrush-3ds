#!/usr/bin/env python3
# Diamond Rush 3DS - modifiche al sorgente di FroggyKVM per il 3DS (ARM11 + percorsi).
# Uso: python3 port/patch_core.py <cartella-froggykvm>
# Ogni modifica verifica di trovare esattamente il testo atteso: se il sorgente
# cambia, lo script si ferma invece di produrre una build sbagliata.
import pathlib
import sys

ROOT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "froggykvm")


def load(rel):
    data = (ROOT / rel).read_bytes().decode("latin-1")
    return data.splitlines(keepends=True)


def save(rel, lines):
    (ROOT / rel).write_bytes("".join(lines).encode("latin-1"))


def eol_of(line):
    return "\r\n" if line.endswith("\r\n") else "\n"


def find_unique(lines, rel, needle, exact=False):
    hits = [i for i, l in enumerate(lines)
            if (l.rstrip("\r\n") == needle if exact else needle in l)]
    if len(hits) != 1:
        sys.exit(f"[patch] {rel}: attesa 1 riga con {needle!r}, trovate {len(hits)}")
    return hits[0]


def replace_line(rel, needle, new_lines, exact=False, first=False):
    lines = load(rel)
    if first:
        hits = [i for i, l in enumerate(lines)
                if (l.rstrip("\r\n") == needle if exact else needle in l)]
        if not hits:
            sys.exit(f"[patch] {rel}: riga {needle!r} non trovata")
        i = hits[0]
    else:
        i = find_unique(lines, rel, needle, exact)
    eol = eol_of(lines[i])
    lines[i:i + 1] = [t + eol for t in new_lines]
    save(rel, lines)
    print(f"[patch] ok  {rel}")


def insert_before(rel, needle, new_lines):
    lines = load(rel)
    i = find_unique(lines, rel, needle)
    eol = eol_of(lines[i])
    lines[i:i] = [t + eol for t in new_lines]
    save(rel, lines)
    print(f"[patch] ok  {rel}")


# 1) Piattaforma "ctr" (3DS, ARM11) nel Makefile del core
replace_line("Makefile", "ifeq ($(platform), sf2000)", [
    "ifeq ($(platform), ctr)",
    "    TOOLPFX := $(if $(DEVKITARM),$(DEVKITARM)/bin/,)arm-none-eabi-",
    "    TARGET := $(NAME)_libretro_ctr.a",
    "    CC = $(TOOLPFX)gcc",
    "    CXX = $(TOOLPFX)g++",
    "    AR = $(TOOLPFX)ar",
    "    CTR_FLAGS = -march=armv6k -mtune=mpcore -mfloat-abi=hard -mfpu=vfp -mtp=soft -mword-relocations"
    " -fno-short-enums -ffunction-sections -fdata-sections -D__3DS__ -DARM11 -DNO_THREADS"
    " -DPSP_COMPAT -DPRODUCT=1 -DFROGGY_NATIVE_FRAME -DFROGGY_SD_ROOT=\\\"sdmc:/3ds/diamondrush\\\"",
    "    override CFLAGS += $(CTR_FLAGS)",
    "    override CXXFLAGS += $(CTR_FLAGS) -fno-exceptions -fno-rtti -fpermissive",
    "    STATIC_LINKING = 1",
    "else ifeq ($(platform), sf2000)",
], exact=True, first=True)

# 2) ARM AAPCS: va_list e' una struct, non si puo' passare NULL
replace_line("pspkvm/cldc/src/vm/cpu/c/Interpreter_c.cpp",
             "invoke_native_entry(native_ptr, return_type, 0, NULL, r1, r2);", [
    "    { va_list no_args; memset(&no_args, 0, sizeof(no_args));"
    " invoke_native_entry(native_ptr, return_type, 0, no_args, r1, r2); }",
])

# 3) Breakpoint: il fallback usava un'istruzione x86 ("int $03")
replace_line("pspkvm/cldc/src/vm/share/utilities/GlobalDefinitions_gcc.hpp",
             '#  define panic() __asm__ ("break")', [
    '#  define panic() __asm__ ("break")',
    "#elif defined(__arm__)",
    "#  define BREAKPOINT __builtin_trap()",
    "#  define panic() __builtin_trap()",
], exact=True)

# 4) classes.zip dentro la RomFS della CIA (controllo di esistenza + classpath reale)
insert_before("pspkvm/platform_gb300/platform.c",
              'FROGGY_SD_ROOT "/cubegm/bios/classes.zip",',
              ['        "romfs:/classes.zip",'])
insert_before("pspkvm/cldc/src/vm/share/handles/Universe.cpp",
              'FROGGY_SD_ROOT "/cubegm/bios/classes.zip",',
              ['        "romfs:/classes.zip",'])

# 5) SoundFont: prima quello nella RomFS (TimGM6mb, GPL-2), poi uno personale sulla SD
insert_before("pspkvm/platform_gb300/audio.c",
              '"/mnt/sda1/bios/Roland_SC-55.sf2",',
              ['    "romfs:/TimGM6mb.sf2",',
               '    FROGGY_SD_ROOT "/music.sf2",'])

# 6) Salvataggi: FroggyKVM scrive in /mnt/sda1/system/saves (percorso dell'SF2000).
#    Sul 3DS vanno in sdmc:/3ds/diamondrush/saves.
replace_line("pspkvm/platform_gb300/rms_posix.c",
             'const char* custom = getenv("GB300_RMS_DIR");', [
    "#ifdef __3DS__",
    '        const char* custom = FROGGY_SD_ROOT "/saves";',
    "#else",
    '        const char* custom = getenv("GB300_RMS_DIR");',
    "#endif",
])

# 7) Frame nativo: consegna al frontend l'immagine J2ME senza ritagliarla a 320x240
insert_before("pspkvm/platform_gb300/video.c",
              "static int last_w = -1, last_h = -1;", [
    "#ifdef FROGGY_NATIVE_FRAME",
    "    {",
    "        retro_video_refresh_t native_vcb = gb300_get_video_cb();",
    "        if (native_vcb) native_vcb(src, src_w, src_h, src_pitch);",
    "        gb300_poll_events();",
    "        return;",
    "    }",
    "#endif",
])

print("[patch] tutte le modifiche applicate")
