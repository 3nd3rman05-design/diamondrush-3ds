#!/usr/bin/env bash
# Diamond Rush 3DS - build completa nel container devkitpro/devkitarm (GitHub Actions).
# Produce: DiamondRush3DS.cia, DiamondRush3DS.3dsx, DiamondRush3DS-QR.png
set -euo pipefail

FROGGY_COMMIT=375e4f6764b71f33e231d015c82c86bfecd58187
FROGGY_RELEASE=https://github.com/Synaps33/FroggyKVM/releases/download/v1.1.1-sf2000/FroggyKVM-J2ME_v1.1.1_SF2000.zip
MAKEROM_ZIP=https://github.com/3DSGuy/Project_CTR/releases/download/makerom-v0.19.0/makerom-v0.19.0-ubuntu_x86_64.zip
BANNERTOOL_TGZ=https://github.com/carstene1ns/3ds-bannertool/releases/download/1.2.3/bannertool-1.2.3-linux.tar.gz

step() { echo; echo "==== $* ===="; }

step "Strumenti"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq --no-install-recommends unzip curl ca-certificates python3 qrencode timgm6mb-soundfont
export PATH="$DEVKITARM/bin:$DEVKITPRO/tools/bin:$PATH"
arm-none-eabi-gcc --version | head -n1

step "FroggyKVM ($FROGGY_COMMIT) + patch 3DS"
rm -rf froggykvm && mkdir froggykvm
curl -sSfL -o froggy.tgz "https://codeload.github.com/Synaps33/FroggyKVM/tar.gz/$FROGGY_COMMIT"
tar -xzf froggy.tgz -C froggykvm --strip-components=1
python3 port/patch_core.py froggykvm

step "Core J2ME per ARM11"
make -C froggykvm -f Makefile platform=ctr -j"$(nproc)"
mkdir -p core/lib core/include
cp froggykvm/j2me_libretro_ctr.a core/lib/libj2me_libretro_ctr.a
cp froggykvm/libretro/core/libretro.h froggykvm/pspkvm/platform_gb300/font8x8.h core/include/

step "RomFS: classes.zip + SoundFont"
mkdir -p romfs
curl -sSfL -o fk.zip "$FROGGY_RELEASE"
unzip -o -q fk.zip classes.zip -d romfs
cp /usr/share/sounds/sf2/TimGM6mb.sf2 romfs/
ls -la romfs

step "Frontend 3DS -> .3dsx"
make -j"$(nproc)"

step "makerom + bannertool"
rm -rf tools && mkdir -p tools/mr tools/bt
curl -sSfL -o makerom.zip "$MAKEROM_ZIP"
unzip -o -q makerom.zip -d tools/mr
curl -sSfL -o bt.tgz "$BANNERTOOL_TGZ"
tar -xzf bt.tgz -C tools/bt
cp "$(find tools/mr -type f -name makerom | head -n1)" tools/makerom
cp "$(find tools/bt -type f -name bannertool | head -n1)" tools/bannertool
chmod +x tools/makerom tools/bannertool

step "CIA"
tools/bannertool makebanner -i meta/banner.png -a meta/banner.wav -o build/banner.bnr
tools/bannertool makesmdh -s "Diamond Rush" -l "Diamond Rush (J2ME) su 3DS" -p "Stezus" -i meta/icon.png -o build/icon.icn
tools/makerom -f cia -o DiamondRush3DS.cia -elf DiamondRush3DS.elf -rsf meta/app.rsf \
    -icon build/icon.icn -banner build/banner.bnr -exefslogo -target t
ls -la DiamondRush3DS.cia DiamondRush3DS.3dsx

step "QR per FBI"
CIA_URL="https://github.com/${GITHUB_REPOSITORY:-utente/repo}/releases/download/build-${GITHUB_RUN_NUMBER:-0}/DiamondRush3DS.cia"
qrencode -s 8 -m 2 -o DiamondRush3DS-QR.png "$CIA_URL"
echo "CIA: $CIA_URL"
