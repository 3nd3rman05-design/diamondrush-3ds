#!/usr/bin/env bash
# Diamond Rush 3DS - build completa nel container devkitpro/devkitarm (GitHub Actions).
# Produce: DiamondRush3DS.cia, DiamondRush3DS.3dsx, DiamondRush3DS-QR.png
set -euo pipefail

FROGGY_COMMIT=375e4f6764b71f33e231d015c82c86bfecd58187
FROGGY_RELEASE=https://github.com/Synaps33/FroggyKVM/releases/download/v1.1.1-sf2000/FroggyKVM-J2ME_v1.1.1_SF2000.zip
# makerom si compila dal sorgente: i binari pubblicati richiedono glibc 2.38, il container ha la 2.36
MAKEROM_SRC=https://codeload.github.com/3DSGuy/Project_CTR/tar.gz/refs/tags/makerom-v0.19.0

CURRENT_STEP="avvio"
step() { CURRENT_STEP="$*"; echo; echo "==== $* ===="; }
on_error() {
    echo
    echo "######## BUILD FALLITA AL PASSO: $CURRENT_STEP ########"
    for f in build-core.log build-frontend.log; do
        [ -f "$f" ] && grep -E " error: |Error [0-9]+|undefined reference|No such file" "$f" | head -n 20
    done
}
trap on_error ERR

step "Strumenti"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq --no-install-recommends unzip curl ca-certificates python3
# facoltativi: se mancano la build continua (niente QR / musica col sintetizzatore interno)
apt-get install -y -qq --no-install-recommends qrencode || echo "AVVISO: qrencode non disponibile"
apt-get install -y -qq --no-install-recommends timgm6mb-soundfont || echo "AVVISO: TimGM6mb non disponibile"
export PATH="$DEVKITARM/bin:$DEVKITPRO/tools/bin:$PATH"
arm-none-eabi-gcc --version | head -n1

step "FroggyKVM ($FROGGY_COMMIT) + patch 3DS"
rm -rf froggykvm && mkdir froggykvm
curl -sSfL -o froggy.tgz "https://codeload.github.com/Synaps33/FroggyKVM/tar.gz/$FROGGY_COMMIT"
tar -xzf froggy.tgz -C froggykvm --strip-components=1
python3 port/patch_core.py froggykvm

step "Core J2ME per ARM11"
make -C froggykvm -f Makefile platform=ctr -j"$(nproc)" 2>&1 | tee build-core.log
mkdir -p core/lib core/include
cp froggykvm/j2me_libretro_ctr.a core/lib/libj2me_libretro_ctr.a
cp froggykvm/libretro/core/libretro.h froggykvm/pspkvm/platform_gb300/font8x8.h core/include/

step "RomFS: classes.zip + SoundFont"
mkdir -p romfs
curl -sSfL -o fk.zip "$FROGGY_RELEASE"
unzip -o -q fk.zip classes.zip -d romfs
if [ -f /usr/share/sounds/sf2/TimGM6mb.sf2 ]; then
    cp /usr/share/sounds/sf2/TimGM6mb.sf2 romfs/
else
    echo "AVVISO: niente SoundFont nella RomFS, la musica usera' il sintetizzatore interno"
fi
ls -la romfs

step "Frontend 3DS -> .3dsx"
make -j"$(nproc)" 2>&1 | tee build-frontend.log

step "makerom (dal sorgente)"
rm -rf tools && mkdir -p tools/src
curl -sSfL -o pctr.tgz "$MAKEROM_SRC"
tar -xzf pctr.tgz -C tools/src --strip-components=1
make -C tools/src/makerom deps -j"$(nproc)" > /dev/null
make -C tools/src/makerom -j"$(nproc)" > /dev/null
cp tools/src/makerom/bin/makerom tools/makerom
tools/makerom 2>&1 | head -n 1 || true

step "CIA"
# banner e icona sono gia' pronti in meta/ (creati con bannertool dalle immagini originali)
tools/makerom -f cia -o DiamondRush3DS.cia -elf DiamondRush3DS.elf -rsf meta/app.rsf \
    -icon meta/icon.icn -banner meta/banner.bnr -exefslogo -target t
ls -la DiamondRush3DS.cia DiamondRush3DS.3dsx

step "QR per FBI"
CIA_URL="https://github.com/${GITHUB_REPOSITORY:-utente/repo}/releases/download/build-${GITHUB_RUN_NUMBER:-0}/DiamondRush3DS.cia"
if command -v qrencode >/dev/null 2>&1; then
    qrencode -s 8 -m 2 -o DiamondRush3DS-QR.png "$CIA_URL"
else
    echo "AVVISO: QR non generato, usa il link qui sotto"
fi
echo "CIA: $CIA_URL"
