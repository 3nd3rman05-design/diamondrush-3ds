/*
 * Diamond Rush 3DS - frontend 3DS per il core J2ME FroggyKVM (linkato staticamente).
 *
 * Schermo superiore: area di gioco a 1:1.
 * Schermo inferiore: barre di stato del gioco, tasti touch e impostazioni.
 *
 * Licenza: GPL-2.0 (come FroggyKVM / PSPKVM / phoneME).
 */
#include <3ds.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "libretro.h"
#include "font8x8.h"

/* Dal core (javacall): invia alla VM un tasto del telefono premuto o rilasciato.
 * I codici sono quelli di javacall_keypress.h: '0'..'9', '*', '#', soft = -6/-7. */
extern void javanotify_key_event(int key, int type);
#define JK_PRESSED  1
#define JK_RELEASED 2
#define JK_SOFT1    (-6)
#define JK_SOFT2    (-7)

/* La VM gira sullo stack del thread principale: 32 KB di default sono pochi. */
u32 __stacksize__ = 0x100000;
/* Heap lineare piccolo (framebuffer + audio): il resto va all'heap della VM. */
u32 __ctru_linear_heap_size = 6u * 1024u * 1024u;

#define BASE_DIR "sdmc:/3ds/diamondrush"
#define JAR_PATH BASE_DIR "/game.jar"
#define CFG_PATH BASE_DIR "/game.cfg"
#define INI_PATH BASE_DIR "/frontend.ini"
#define LOG_PATH BASE_DIR "/log.txt"
#define LOG_CAP (512u * 1024u)

#define TOP_W 400
#define BOT_W 320
#define SCR_H 240
#define HUD_H 86

#define RGB8_565(r, g, b) ((u16)((((r) & 0xF8) << 8) | (((g) & 0xFC) << 3) | ((b) >> 3)))
#define COL_BG     RGB8_565(18, 20, 28)
#define COL_BTN    RGB8_565(52, 58, 76)
#define COL_BTN_HI RGB8_565(96, 110, 150)
#define COL_EDGE   RGB8_565(120, 130, 160)
#define COL_TXT    RGB8_565(235, 235, 240)
#define COL_DIM    RGB8_565(150, 155, 170)
#define COL_WARN   RGB8_565(255, 190, 60)

/* ------------------------------------------------------------------ opzioni */
enum { LAYOUT_SPLIT = 0, LAYOUT_CENTER = 1 };
static int opt_layout = LAYOUT_SPLIT; /* diviso: gioco sopra, barre sotto */
static int opt_split_y = 40;          /* 1.1.7: l'area di gioco parte dalla riga 40 */
static int opt_hud_b = 276;           /* 1.1.7: la barra in basso (con le ampolle) parte dalla 276 */
static int opt_log = 1;
static int opt_audio = 1;             /* 0 = muto (la sintesi MIDI gira comunque) */
static int opt_vsync = 0;

/* ------------------------------------------------------------------- stato */
static FILE *log_fp = NULL;
static size_t log_bytes = 0;
static bool is_new3ds = false;
static bool audio_ok = false;

static u32 keys_held = 0, keys_down_acc = 0;
static bool touching = false;
static touchPosition touch_pos;

static int last_w = -1, last_h = -1;
static int top_clear = 2;
static bool ui_dirty = true;
static int last_pressed = -2;
static u32 fps_frames = 0, fps_value = 0;
static u64 fps_t0 = 0;

/* ------------------------------------------------------------------- log */
static void log_vwrite(const char *fmt, va_list ap)
{
    if (!log_fp || log_bytes >= LOG_CAP)
        return;
    int n = vfprintf(log_fp, fmt, ap);
    if (n > 0)
        log_bytes += (size_t)n;
    if (log_bytes >= LOG_CAP) {
        fputs("\n[log troncato a 512 KB]\n", log_fp);
        fflush(log_fp);
    }
}

/* Sostituisce lo xlog "weak" del core: niente formattazione se il log e' spento. */
void xlog(const char *fmt, ...)
{
    if (!opt_log)
        return;
    va_list ap;
    va_start(ap, fmt);
    log_vwrite(fmt, ap);
    va_end(ap);
}

static void core_log(enum retro_log_level level, const char *fmt, ...)
{
    (void)level;
    if (!opt_log)
        return;
    va_list ap;
    va_start(ap, fmt);
    log_vwrite(fmt, ap);
    va_end(ap);
}

static void flog(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    log_vwrite(fmt, ap);
    va_end(ap);
    if (log_fp)
        fflush(log_fp);
}

/* ------------------------------------------------- disegno (framebuffer ruotati)
 * Sul 3DS il pixel (x, y) dello schermo sta in fb[x * 240 + (239 - y)]. */
static inline u16 *fb_top(void) { return (u16 *)gfxGetFramebuffer(GFX_TOP, GFX_LEFT, NULL, NULL); }
static inline u16 *fb_bot(void) { return (u16 *)gfxGetFramebuffer(GFX_BOTTOM, GFX_LEFT, NULL, NULL); }

static void fill(u16 *fb, int scr_w, int x, int y, int w, int h, u16 c)
{
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > scr_w) w = scr_w - x;
    if (y + h > SCR_H) h = SCR_H - y;
    for (int i = 0; i < w; i++) {
        u16 *col = fb + (x + i) * SCR_H + (SCR_H - 1 - y);
        for (int j = 0; j < h; j++)
            *col-- = c;
    }
}

static void blit(u16 *fb, int scr_w, int dx, int dy, const u16 *src, int pitch,
                 int sx, int sy, int w, int h)
{
    if (dx < 0) { sx -= dx; w += dx; dx = 0; }
    if (dy < 0) { sy -= dy; h += dy; dy = 0; }
    if (dx + w > scr_w) w = scr_w - dx;
    if (dy + h > SCR_H) h = SCR_H - dy;
    if (w <= 0 || h <= 0)
        return;
    for (int i = 0; i < w; i++) {
        u16 *col = fb + (dx + i) * SCR_H + (SCR_H - 1 - dy);
        const u16 *s = src + sy * pitch + sx + i;
        for (int j = 0; j < h; j++) {
            *col-- = *s;
            s += pitch;
        }
    }
}

static void text(u16 *fb, int scr_w, int x, int y, const char *str, u16 fg)
{
    for (; *str; str++, x += 8) {
        unsigned c = (unsigned char)*str;
        if (c < 32 || c > 126)
            c = '?';
        const uint8_t *g = font8x8_basic[c - 32];
        for (int r = 0; r < 8; r++) {
            int py = y + r;
            if (py < 0 || py >= SCR_H)
                continue;
            for (int b = 0; b < 8; b++) {
                int px = x + b;
                if (px >= 0 && px < scr_w && (g[r] & (0x80 >> b)))
                    fb[px * SCR_H + (SCR_H - 1 - py)] = fg;
            }
        }
    }
}

/* ------------------------------------------------------- schermo inferiore */
enum { ACT_KEY = 0, ACT_LAYOUT, ACT_AUDIO, ACT_KEYPAD, ACT_EXIT };
typedef struct {
    int x, y, w, h;
    const char *label;  /* cosa fa */
    const char *hint;   /* tasti fisici equivalenti */
    int retro_id;       /* tasto RetroPad premuto (ACT_KEY) */
    int action;
    bool confirm;       /* richiede due tocchi */
} Button;

/* Le funzioni vengono dal codice di Diamond Rush 1.1.7:
 *  5 = OK e azione; tasto funzione sinistro = menu di pausa in gioco, "Salta" nei dialoghi
 *  (verificato su desktop); tasto funzione destro = indietro nei menu;
 *  * = torna all'ultimo checkpoint (costa una vita se non ci sei sopra).
 *  0 e # non servono al gioco (il # entra solo in un codice cheat).
 * I tasti touch premono gli stessi tasti RetroPad dei pulsanti fisici, mappati in game.cfg. */
static const Button buttons[] = {
    {   8,  88,  96, 40, "OK / Azione", "A  X",     RETRO_DEVICE_ID_JOYPAD_A,      ACT_KEY,    false },
    { 112,  88,  96, 40, "Menu/Salta",  "START  L", RETRO_DEVICE_ID_JOYPAD_START,  ACT_KEY,    false },
    { 216,  88,  96, 40, "Indietro",    "B  Y  R",  RETRO_DEVICE_ID_JOYPAD_B,      ACT_KEY,    false },
    {   8, 134,  96, 40, "Checkpoint",  "SELECT",   RETRO_DEVICE_ID_JOYPAD_SELECT, ACT_KEY,    true  },
    { 112, 134,  96, 40, "Schermo",     NULL,       -1,                            ACT_LAYOUT, false },
    { 216, 134,  96, 40, "Audio",       NULL,       -1,                            ACT_AUDIO,  false },
    {   8, 180, 148, 36, "Cheat / Tastiera", NULL,  -1,                            ACT_KEYPAD, false },
    { 164, 180, 148, 36, "Esci",        NULL,       -1,                            ACT_EXIT,   true  },
};
#define NBUTTONS ((int)(sizeof(buttons) / sizeof(buttons[0])))

static int armed = -1;          /* pulsante "a due tocchi" in attesa di conferma */
static u64 armed_until = 0;
static int pulse_id = -1;       /* tasto premuto per un attimo dopo la conferma */
static u64 pulse_until = 0;

static int button_at(int px, int py)
{
    for (int i = 0; i < NBUTTONS; i++) {
        const Button *b = &buttons[i];
        if (px >= b->x && px < b->x + b->w && py >= b->y && py < b->y + b->h)
            return i;
    }
    return -1;
}

/* ------------------------------------------------- tastiera del telefono */
enum { PAD_KEY = 0, PAD_MACRO, PAD_LIST, PAD_CLOSE };
typedef struct { int x, y, w, h; const char *label; int jkey; int action; } PadKey;
static const PadKey padkeys[] = {
    {   8,  88, 64, 30, "1", '1', PAD_KEY }, {  76,  88, 64, 30, "2", '2', PAD_KEY }, { 144,  88, 64, 30, "3", '3', PAD_KEY },
    {   8, 120, 64, 30, "4", '4', PAD_KEY }, {  76, 120, 64, 30, "5", '5', PAD_KEY }, { 144, 120, 64, 30, "6", '6', PAD_KEY },
    {   8, 152, 64, 30, "7", '7', PAD_KEY }, {  76, 152, 64, 30, "8", '8', PAD_KEY }, { 144, 152, 64, 30, "9", '9', PAD_KEY },
    {   8, 184, 64, 30, "*", '*', PAD_KEY }, {  76, 184, 64, 30, "0", '0', PAD_KEY }, { 144, 184, 64, 30, "#", '#', PAD_KEY },
    { 216,  88, 96, 22, "Cheat #4772", 0,        PAD_MACRO },
    { 216, 114, 96, 22, "Lista cheat", 0,        PAD_LIST  },
    { 216, 140, 96, 22, "Menu/Salta",  JK_SOFT1, PAD_KEY   },
    { 216, 166, 96, 22, "Indietro",    JK_SOFT2, PAD_KEY   },
    { 216, 192, 96, 22, "Chiudi",      0,        PAD_CLOSE },
};
#define NPAD ((int)(sizeof(padkeys) / sizeof(padkeys[0])))

static bool keypad_open = false;
static int pad_active = -1;
/* In gioco (o sulla mappa) la sequenza # 4 7 7 2 apre la pagina dei cheat del gioco. */
static const int cheat_seq[] = { '#', '4', '7', '7', '2' };
#define NCHEAT ((int)(sizeof(cheat_seq) / sizeof(cheat_seq[0])))
static int macro_pos = -1;
static bool macro_down = false;
static u64 macro_next = 0;

static bool cheatlist_open = false;
/* Dal codice di Diamond Rush 1.1.7, verificato su desktop dove indicato nel README. */
static const char *const cheat_lines[] = {
    "CHEAT DI DIAMOND RUSH 1.1.7",
    "Apri: # 4 7 7 2 in un livello o sulla",
    "mappa, oppure tocca \"Cheat #4772\".",
    "",
    "Sulla pagina dei cheat:",
    " 6  +50 diamanti",
    " 7  +5 diamanti rossi",
    " 8  armi disponibili (dalla mappa)",
    " 9  sblocca tutti i livelli",
    " 0  sblocca i livelli segreti",
    " #  attiva salta-livello",
    "Menu/Salta applica e salva,",
    "Indietro esce senza applicare.",
    "",
    "Con salta-livello attivo, in gioco:",
    " 9  livello superato",
    " 7  torna alla mappa",
    "",
    "Sempre: * torna al cerchio magico",
    "(costa una vita).",
    "Tocca lo schermo per tornare",
};
#define NCHEATLINES ((int)(sizeof(cheat_lines) / sizeof(cheat_lines[0])))

static int pad_at(int px, int py)
{
    for (int i = 0; i < NPAD; i++) {
        const PadKey *p = &padkeys[i];
        if (px >= p->x && px < p->x + p->w && py >= p->y && py < p->y + p->h)
            return i;
    }
    return -1;
}

/* Chiamata dentro l'input poll del core: stesso contesto dei tasti fisici. */
static void keypad_poll(u32 kd)
{
    u64 now = osGetTime();
    if (macro_pos >= 0 && now >= macro_next) {
        int k = cheat_seq[macro_pos];
        if (!macro_down) {
            javanotify_key_event(k, JK_PRESSED);
            macro_down = true;
            macro_next = now + 80;
        } else {
            javanotify_key_event(k, JK_RELEASED);
            macro_down = false;
            macro_next = now + 120;
            if (++macro_pos >= NCHEAT) {
                macro_pos = -1;
                ui_dirty = true;
            }
        }
    }
    int hit = (touching && !cheatlist_open) ? pad_at(touch_pos.px, touch_pos.py) : -1;
    if (pad_active >= 0 && hit != pad_active) {
        javanotify_key_event(padkeys[pad_active].jkey, JK_RELEASED);
        pad_active = -1;
        ui_dirty = true;
    }
    if (cheatlist_open) { /* la lista copre la tastiera: un tocco qualsiasi la chiude */
        if (kd & KEY_TOUCH) {
            cheatlist_open = false;
            ui_dirty = true;
        }
        return;
    }
    if (!(kd & KEY_TOUCH) || hit < 0)
        return;
    const PadKey *p = &padkeys[hit];
    switch (p->action) {
    case PAD_KEY:
        javanotify_key_event(p->jkey, JK_PRESSED);
        pad_active = hit;
        break;
    case PAD_MACRO:
        if (macro_pos < 0) {
            macro_pos = 0;
            macro_down = false;
            macro_next = now;
        }
        break;
    case PAD_LIST:
        cheatlist_open = true;
        break;
    case PAD_CLOSE:
        keypad_open = false;
        cheatlist_open = false;
        break;
    }
    ui_dirty = true;
}

static void draw_keypad(u16 *fb)
{
    if (cheatlist_open) {
        fill(fb, BOT_W, 0, 0, BOT_W, 218, COL_BG);
        for (int i = 0; i < NCHEATLINES; i++)
            text(fb, BOT_W, 4, 4 + i * 10, cheat_lines[i],
                 i == 0 ? COL_WARN : (i == NCHEATLINES - 1 ? COL_DIM : COL_TXT));
        return;
    }
    for (int i = 0; i < NPAD; i++) {
        const PadKey *p = &padkeys[i];
        bool hi = i == pad_active || (p->action == PAD_MACRO && macro_pos >= 0);
        fill(fb, BOT_W, p->x, p->y, p->w, p->h, p->action == PAD_MACRO ? COL_WARN : COL_EDGE);
        fill(fb, BOT_W, p->x + 1, p->y + 1, p->w - 2, p->h - 2, hi ? COL_BTN_HI : COL_BTN);
        int tw = (int)strlen(p->label) * 8;
        text(fb, BOT_W, p->x + (p->w - tw) / 2, p->y + (p->h - 8) / 2, p->label, COL_TXT);
    }
}

static void draw_status(void)
{
    u16 *fb = fb_bot();
    char buf[48];
    snprintf(buf, sizeof buf, "%s  %2lu fps  audio %s",
             is_new3ds ? "New 3DS" : "Old 3DS", (unsigned long)fps_value, audio_ok ? "ok" : "no");
    fill(fb, BOT_W, 0, 222, BOT_W, 18, COL_BG);
    text(fb, BOT_W, 8, 227, buf, COL_DIM);
}

static void draw_text_centered(u16 *fb, const Button *b, int y, const char *str, u16 col)
{
    int tw = (int)strlen(str) * 8;
    text(fb, BOT_W, b->x + (b->w - tw) / 2, y, str, col);
}

static void draw_ui(void)
{
    u16 *fb = fb_bot();
    fill(fb, BOT_W, 0, 0, BOT_W, SCR_H, COL_BG);
    for (int i = 0; i < NBUTTONS && !keypad_open; i++) {
        const Button *b = &buttons[i];
        bool pressed = touching && button_at(touch_pos.px, touch_pos.py) == i;
        const char *hint = b->hint;
        u16 hint_col = COL_DIM;
        if (b->action == ACT_LAYOUT)
            hint = opt_layout == LAYOUT_SPLIT ? "diviso" : "centrato";
        else if (b->action == ACT_AUDIO)
            hint = opt_audio ? "acceso" : "muto";
        if (armed == i) {
            hint = "tocca ancora";
            hint_col = COL_WARN;
        }
        fill(fb, BOT_W, b->x, b->y, b->w, b->h, armed == i ? COL_WARN : COL_EDGE);
        fill(fb, BOT_W, b->x + 1, b->y + 1, b->w - 2, b->h - 2, pressed ? COL_BTN_HI : COL_BTN);
        int ly = hint ? b->y + b->h / 2 - 10 : b->y + (b->h - 8) / 2;
        draw_text_centered(fb, b, ly, b->label, COL_TXT);
        if (hint)
            draw_text_centered(fb, b, b->y + b->h / 2 + 4, hint, hint_col);
    }
    if (keypad_open)
        draw_keypad(fb);
    if (opt_layout != LAYOUT_SPLIT)
        text(fb, BOT_W, 8, 36, "Barre di stato sullo schermo sopra", COL_DIM);
    draw_status();
    ui_dirty = false;
}

/* Le righe sopra e sotto l'area di gioco (vite, chiavi, energia) vanno qui sotto. */
static void draw_hud(const u16 *src, int w, int h, int pitch)
{
    u16 *fb = fb_bot();
    int top_rows = opt_split_y > HUD_H ? HUD_H : opt_split_y;
    int bot_y0 = opt_hud_b;
    int bot_rows = h - bot_y0;
    if (bot_rows < 0)
        bot_rows = 0;
    if (top_rows + bot_rows > HUD_H)
        bot_rows = HUD_H - top_rows;
    int cw = w > BOT_W ? BOT_W : w;
    int sx = (w - cw) / 2;
    int dx = (BOT_W - cw) / 2;
    blit(fb, BOT_W, dx, 0, src, pitch, sx, 0, cw, top_rows);
    if (bot_rows > 0)
        blit(fb, BOT_W, dx, top_rows, src, pitch, sx, bot_y0, cw, bot_rows);
}

/* ---------------------------------------------------------- impostazioni */
static void save_ini(void)
{
    FILE *f = fopen(INI_PATH, "w");
    if (!f)
        return;
    fprintf(f, "# Diamond Rush 3DS - impostazioni del frontend\n");
    fprintf(f, "# layout = diviso (gioco sopra, barre sotto) | centro\n");
    fprintf(f, "layout = %s\n", opt_layout == LAYOUT_SPLIT ? "diviso" : "centro");
    fprintf(f, "# prima riga dell'area di gioco nell'immagine del gioco (1.1.7: 40)\n");
    fprintf(f, "split_y = %d\n", opt_split_y);
    fprintf(f, "# prima riga della barra in basso da copiare sotto (1.1.7: 276)\n");
    fprintf(f, "hud_b = %d\n", opt_hud_b);
    fprintf(f, "# log.txt: 1 = attivo, 0 = spento (un po' piu' veloce)\n");
    fprintf(f, "log = %d\n", opt_log);
    fprintf(f, "# audio: 1 = acceso, 0 = muto\n");
    fprintf(f, "audio = %d\n", opt_audio);
    fprintf(f, "# attendi il vsync: 0 = piu' veloce, 1 = niente tearing\n");
    fprintf(f, "vsync = %d\n", opt_vsync);
    fclose(f);
}

static void load_ini(void)
{
    FILE *f = fopen(INI_PATH, "r");
    if (!f)
        return;
    char line[128];
    while (fgets(line, sizeof line, f)) {
        char key[32], val[64];
        if (line[0] == '#' || sscanf(line, " %31[a-z_] = %63s", key, val) != 2)
            continue;
        if (!strcmp(key, "layout"))
            opt_layout = !strcmp(val, "centro") ? LAYOUT_CENTER : LAYOUT_SPLIT;
        else if (!strcmp(key, "split_y")) {
            int v = atoi(val);
            if (v >= 0 && v <= 160)
                opt_split_y = v;
        } else if (!strcmp(key, "hud_b")) {
            int v = atoi(val);
            if (v >= 0 && v <= 512)
                opt_hud_b = v;
        } else if (!strcmp(key, "log"))
            opt_log = atoi(val) != 0;
        else if (!strcmp(key, "audio"))
            opt_audio = atoi(val) != 0;
        else if (!strcmp(key, "vsync"))
            opt_vsync = atoi(val) != 0;
    }
    fclose(f);
}

static bool file_exists(const char *path)
{
    struct stat st;
    return stat(path, &st) == 0;
}

static void write_default_cfg(void)
{
    if (file_exists(CFG_PATH))
        return;
    FILE *f = fopen(CFG_PATH, "w");
    if (!f)
        return;
    fputs("# Diamond Rush 3DS - configurazione del core FroggyKVM\n"
          "# Risoluzione del .jar: 1.1.7 Nokia = 240x320, 1.2.0 \"(a)\" = 176x204\n"
          "resolution = 240x320\n"
          "heap = 16M\n"
          "enable_combos = 0\n"
          "# Tasti 3DS -> tasti del telefono\n"
          "#  5 = OK/azione, SOFT1 = menu di pausa/salta, SOFT2 = indietro,\n"
          "#  ASTERISK = torna all'ultimo checkpoint (costa una vita se non ci sei sopra)\n"
          "UP = 2\n"
          "DOWN = 8\n"
          "LEFT = 4\n"
          "RIGHT = 6\n"
          "A = 5\n"
          "X = 5\n"
          "B = SOFT2\n"
          "Y = SOFT2\n"
          "START = SOFT1\n"
          "L = SOFT1\n"
          "R = SOFT2\n"
          "SELECT = ASTERISK\n", f);
    fclose(f);
}

/* ------------------------------------------------------------------ audio */
#define AUDIO_RATE 22050
#define WB_FRAMES 1024
#define WB_COUNT 8
static ndspWaveBuf wb[WB_COUNT];
static s16 *wb_mem = NULL;
static int wb_cur = 0, wb_fill = 0;

static bool audio_init(void)
{
    if (R_FAILED(ndspInit())) {
        flog("[3DS] audio non disponibile: manca sdmc:/3ds/dspfirm.cdc?\n");
        return false;
    }
    wb_mem = (s16 *)linearAlloc(WB_COUNT * WB_FRAMES * 2 * sizeof(s16));
    if (!wb_mem) {
        ndspExit();
        return false;
    }
    memset(wb_mem, 0, WB_COUNT * WB_FRAMES * 2 * sizeof(s16));
    ndspSetOutputMode(NDSP_OUTPUT_STEREO);
    ndspChnReset(0);
    ndspChnSetInterp(0, NDSP_INTERP_LINEAR);
    ndspChnSetRate(0, AUDIO_RATE);
    ndspChnSetFormat(0, NDSP_FORMAT_STEREO_PCM16);
    float mix[12];
    memset(mix, 0, sizeof mix);
    mix[0] = mix[1] = 1.0f;
    ndspChnSetMix(0, mix);
    memset(wb, 0, sizeof wb);
    for (int i = 0; i < WB_COUNT; i++) {
        wb[i].data_pcm16 = wb_mem + i * WB_FRAMES * 2;
        wb[i].nsamples = WB_FRAMES;
        wb[i].status = NDSP_WBUF_DONE;
    }
    return true;
}

static void audio_shutdown(void)
{
    if (!audio_ok)
        return;
    audio_ok = false;
    ndspChnWaveBufClear(0);
    ndspExit();
    if (wb_mem)
        linearFree(wb_mem);
    wb_mem = NULL;
}

static size_t audio_batch_cb(const int16_t *data, size_t frames)
{
    if (!audio_ok || !opt_audio)
        return frames;
    size_t done = 0;
    while (done < frames) {
        ndspWaveBuf *b = &wb[wb_cur];
        if (b->status == NDSP_WBUF_QUEUED || b->status == NDSP_WBUF_PLAYING)
            break; /* il DSP e' indietro: scarta il resto invece di bloccare la VM */
        size_t n = frames - done;
        if (n > (size_t)(WB_FRAMES - wb_fill))
            n = (size_t)(WB_FRAMES - wb_fill);
        memcpy(b->data_pcm16 + wb_fill * 2, data + done * 2, n * 2 * sizeof(s16));
        wb_fill += (int)n;
        done += n;
        if (wb_fill == WB_FRAMES) {
            DSP_FlushDataCache(b->data_pcm16, WB_FRAMES * 2 * sizeof(s16));
            ndspChnWaveBufAdd(0, b);
            wb_cur = (wb_cur + 1) % WB_COUNT;
            wb_fill = 0;
        }
    }
    return frames;
}

static void audio_sample_cb(int16_t left, int16_t right)
{
    int16_t s[2] = { left, right };
    audio_batch_cb(s, 1);
}

/* ------------------------------------------------------------------ input */
static const u32 joy_map[16] = {
    [RETRO_DEVICE_ID_JOYPAD_B]      = KEY_B,
    [RETRO_DEVICE_ID_JOYPAD_Y]      = KEY_Y,
    [RETRO_DEVICE_ID_JOYPAD_SELECT] = KEY_SELECT,
    [RETRO_DEVICE_ID_JOYPAD_START]  = KEY_START,
    [RETRO_DEVICE_ID_JOYPAD_UP]     = KEY_UP,
    [RETRO_DEVICE_ID_JOYPAD_DOWN]   = KEY_DOWN,
    [RETRO_DEVICE_ID_JOYPAD_LEFT]   = KEY_LEFT,
    [RETRO_DEVICE_ID_JOYPAD_RIGHT]  = KEY_RIGHT,
    [RETRO_DEVICE_ID_JOYPAD_A]      = KEY_A,
    [RETRO_DEVICE_ID_JOYPAD_X]      = KEY_X,
    [RETRO_DEVICE_ID_JOYPAD_L]      = KEY_L | KEY_ZL,
    [RETRO_DEVICE_ID_JOYPAD_R]      = KEY_R | KEY_ZR,
};

static void input_poll_cb(void)
{
    hidScanInput();
    keys_held = hidKeysHeld();
    u32 kd = hidKeysDown();
    touching = (keys_held & KEY_TOUCH) != 0;
    if (touching)
        hidTouchRead(&touch_pos);
    if (keypad_open) {
        keypad_poll(kd);
        kd &= ~(u32)KEY_TOUCH; /* i tocchi sulla tastiera non vanno ai pulsanti normali */
    }
    keys_down_acc |= kd;
}

static int16_t input_state_cb(unsigned port, unsigned device, unsigned index, unsigned id)
{
    (void)index;
    if (port != 0 || device != RETRO_DEVICE_JOYPAD || id >= 16)
        return 0;
    if (keys_held & joy_map[id])
        return 1;
    if ((int)id == pulse_id && osGetTime() < pulse_until)
        return 1;
    if (touching && !keypad_open) {
        int b = button_at(touch_pos.px, touch_pos.py);
        if (b >= 0 && buttons[b].action == ACT_KEY && !buttons[b].confirm &&
            buttons[b].retro_id == (int)id)
            return 1;
    }
    return 0;
}

/* --------------------------------------------------------------- uscita */
static void quit_now(void)
{
    flog("[3DS] uscita\n");
    audio_shutdown();
    romfsExit();
    gfxExit();
    exit(0);
}

static void handle_touch_actions(u32 kd)
{
    u64 now = osGetTime();
    if (armed >= 0 && now > armed_until) {
        armed = -1;
        ui_dirty = true;
    }
    if (keypad_open)
        return;
    int pressed = touching ? button_at(touch_pos.px, touch_pos.py) : -1;
    if (pressed != last_pressed) {
        last_pressed = pressed;
        ui_dirty = true;
    }
    if (!(kd & KEY_TOUCH) || pressed < 0)
        return;
    const Button *b = &buttons[pressed];
    if (b->confirm && armed != pressed) {
        armed = pressed; /* primo tocco: chiedi conferma per 3 secondi */
        armed_until = now + 3000;
        ui_dirty = true;
        return;
    }
    armed = -1;
    ui_dirty = true;
    switch (b->action) {
    case ACT_LAYOUT:
        opt_layout = opt_layout == LAYOUT_SPLIT ? LAYOUT_CENTER : LAYOUT_SPLIT;
        top_clear = 2;
        save_ini();
        break;
    case ACT_AUDIO:
        opt_audio = !opt_audio;
        save_ini();
        break;
    case ACT_KEYPAD:
        keypad_open = true;
        pad_active = -1;
        break;
    case ACT_EXIT:
        quit_now();
        break;
    default:
        if (b->confirm) { /* secondo tocco: premi il tasto per un attimo */
            pulse_id = b->retro_id;
            pulse_until = now + 150;
        }
        break;
    }
}

/* ------------------------------------------------------------------ video */
static void video_cb(const void *data, unsigned width, unsigned height, size_t pitch)
{
    if (!aptMainLoop())
        quit_now();

    u32 kd = keys_down_acc;
    keys_down_acc = 0;
    handle_touch_actions(kd);

    if (!data) /* fotogramma ripetuto: lo schermo mostra gia' quello giusto */
        return;
    {
        int w = (int)width, h = (int)height, p = (int)(pitch / sizeof(u16));
        const u16 *src = (const u16 *)data;
        if (w != last_w || h != last_h) {
            last_w = w;
            last_h = h;
            top_clear = 2;
            ui_dirty = true;
            flog("[3DS] immagine del gioco %dx%d\n", w, h);
        }
        bool split = opt_layout == LAYOUT_SPLIT && h >= opt_split_y + SCR_H;
        u16 *top = fb_top();
        if (top_clear > 0) {
            fill(top, TOP_W, 0, 0, TOP_W, SCR_H, 0);
            top_clear--;
        }
        if (split)
            blit(top, TOP_W, (TOP_W - w) / 2, 0, src, p, 0, opt_split_y, w, SCR_H);
        else
            blit(top, TOP_W, (TOP_W - w) / 2, (SCR_H - h) / 2, src, p, 0, 0, w, h);
        if (ui_dirty)
            draw_ui();
        if (split && !(keypad_open && cheatlist_open))
            draw_hud(src, w, h, p);
    }

    fps_frames++;
    u64 now = osGetTime();
    if (now - fps_t0 >= 1000) {
        fps_value = (u32)(fps_frames * 1000u / (u32)(now - fps_t0));
        fps_frames = 0;
        fps_t0 = now;
        draw_status();
        if (log_fp)
            fflush(log_fp);
    }

    gfxFlushBuffers();
    gfxSwapBuffers();
    if (opt_vsync)
        gspWaitForVBlank();
}

/* ------------------------------------------------------------ libretro env */
static bool env_cb(unsigned cmd, void *data)
{
    switch (cmd) {
    case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
    case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY:
        *(const char **)data = BASE_DIR;
        return true;
    case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:
        return *(const enum retro_pixel_format *)data == RETRO_PIXEL_FORMAT_RGB565;
    case RETRO_ENVIRONMENT_GET_LOG_INTERFACE:
        ((struct retro_log_callback *)data)->log = core_log;
        return true;
    case RETRO_ENVIRONMENT_GET_CAN_DUPE:
        *(bool *)data = true;
        return true;
    case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
    case RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL:
    case RETRO_ENVIRONMENT_SHUTDOWN:
        return true;
    default:
        return false;
    }
}

/* ---------------------------------------------------------------- errori */
static void fatal_screen(const char *l1, const char *l2, const char *l3)
{
    flog("[3DS] ERRORE: %s - %s %s\n", l1, l2, l3);
    while (aptMainLoop()) {
        hidScanInput();
        if (hidKeysDown() & KEY_START)
            break;
        u16 *t = fb_top();
        fill(t, TOP_W, 0, 0, TOP_W, SCR_H, COL_BG);
        text(t, TOP_W, 16, 80, l1, COL_WARN);
        text(t, TOP_W, 16, 104, l2, COL_TXT);
        text(t, TOP_W, 16, 120, l3, COL_TXT);
        text(t, TOP_W, 16, 200, "Premi START per uscire", COL_DIM);
        u16 *b = fb_bot();
        fill(b, BOT_W, 0, 0, BOT_W, SCR_H, COL_BG);
        gfxFlushBuffers();
        gfxSwapBuffers();
        gspWaitForVBlank();
    }
}

/* ------------------------------------------------------------------- main */
int main(void)
{
    gfxInit(GSP_RGB565_OES, GSP_RGB565_OES, false);
    gfxSetDoubleBuffering(GFX_BOTTOM, false);
    gfxSet3D(false);
    osSetSpeedupEnable(true); /* New 3DS: 804 MHz + cache L2; nessun effetto sull'Old */
    APT_CheckNew3DS(&is_new3ds);

    mkdir("sdmc:/3ds", 0777);
    mkdir(BASE_DIR, 0777);
    mkdir(BASE_DIR "/saves", 0777);

    load_ini();
    save_ini();
    log_fp = fopen(LOG_PATH, "w");
    if (log_fp)
        setvbuf(log_fp, NULL, _IOFBF, 16 * 1024);
    flog("[3DS] Diamond Rush 3DS - %s\n", is_new3ds ? "New 3DS" : "Old 3DS");

    Result rc = romfsInit();
    flog("[3DS] romfs: %08lX\n", (unsigned long)rc);
    write_default_cfg();
    fps_t0 = osGetTime();

    if (!file_exists(JAR_PATH)) {
        fatal_screen("Manca il gioco.", "Copia il .jar e rinominalo:", JAR_PATH);
        goto out;
    }
    if (R_FAILED(rc) || !file_exists("romfs:/classes.zip")) {
        fatal_screen("RomFS non trovata.", "Avvia la CIA, oppure il .3dsx", "compilato con la sua romfs.");
        goto out;
    }

    audio_ok = audio_init();

    retro_set_environment(env_cb);
    retro_set_video_refresh(video_cb);
    retro_set_audio_sample(audio_sample_cb);
    retro_set_audio_sample_batch(audio_batch_cb);
    retro_set_input_poll(input_poll_cb);
    retro_set_input_state(input_state_cb);
    retro_init();

    struct retro_game_info info = { JAR_PATH, NULL, 0, NULL };
    if (!retro_load_game(&info)) {
        fatal_screen("Il core non ha caricato il gioco.", "Guarda log.txt in", BASE_DIR);
        retro_deinit();
        goto out;
    }

    ui_dirty = true;
    retro_run(); /* la VM gira qui dentro finche' il gioco non termina */
    flog("[3DS] gioco terminato\n");
    retro_unload_game();
    retro_deinit();

out:
    flog("[3DS] fine\n");
    audio_shutdown();
    romfsExit();
    gfxExit();
    return 0;
}
